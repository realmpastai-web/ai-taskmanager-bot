const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('topusers')
    .setDescription('🏆 View most active members')
    .addStringOption(option =>
      option
        .setName('period')
        .setDescription('Time period')
        .setRequired(false)
        .addChoices(
          { name: 'Today', value: 'day' },
          { name: 'This Week', value: 'week' },
          { name: 'This Month', value: 'month' },
          { name: 'All Time', value: 'all' }
        )
    )
    .addIntegerOption(option =>
      option
        .setName('limit')
        .setDescription('Number of users to show (max 20)')
        .setRequired(false)
        .setMinValue(5)
        .setMaxValue(20)
    ),

  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      const db = client.db;
      const period = interaction.options.getString('period') || 'all';
      const limit = interaction.options.getInteger('limit') || 10;
      
      const periodLabels = {
        day: 'Today',
        week: 'This Week',
        month: 'This Month',
        all: 'All Time'
      };
      
      // Get top users
      const topUsers = await db.getTopUsers(guild.id, limit, period);
      
      if (topUsers.length === 0) {
        return interaction.editReply({
          content: '📊 No message data available yet. Stats are collected as messages are sent.'
        });
      }
      
      // Build leaderboard
      let leaderboard = '';
      const medals = ['🥇', '🥈', '🥉'];
      
      for (let i = 0; i < topUsers.length; i++) {
        const user = topUsers[i];
        const prefix = medals[i] || `\`#${(i + 1).toString().padStart(2)}\``;
        leaderboard += `${prefix} <@${user.user_id}> — **${user.message_count.toLocaleString()}** messages\n`;
      }
      
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle(`🏆 Top Members - ${periodLabels[period]}`)
        .setDescription(`**${guild.name}**\n\n${leaderboard}`)
        .setFooter({ text: 'Server Stats Bot • QuantZen' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Error in topusers command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while fetching user statistics.'
      });
    }
  }
};
