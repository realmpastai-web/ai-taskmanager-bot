const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('channelstats')
    .setDescription('📁 View channel activity statistics')
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('Specific channel to analyze (optional)')
        .setRequired(false)
    )
    .addStringOption(option =>
      option
        .setName('period')
        .setDescription('Time period')
        .setRequired(false)
        .addChoices(
          { name: '7 Days', value: '7' },
          { name: '30 Days', value: '30' },
          { name: '90 Days', value: '90' }
        )
    ),

  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      const db = client.db;
      const targetChannel = interaction.options.getChannel('channel');
      const days = parseInt(interaction.options.getString('period') || '30');
      
      if (targetChannel) {
        // Specific channel stats
        const channelMessages = await db.all(
          `SELECT COUNT(*) as count FROM message_stats 
           WHERE guild_id = ? AND channel_id = ? AND timestamp > datetime('now', '-${days} days')`,
          [guild.id, targetChannel.id]
        );
        
        const uniqueUsers = await db.all(
          `SELECT COUNT(DISTINCT user_id) as count FROM message_stats 
           WHERE guild_id = ? AND channel_id = ? AND timestamp > datetime('now', '-${days} days')`,
          [guild.id, targetChannel.id]
        );
        
        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle(`📁 #${targetChannel.name} Statistics`)
          .addFields(
            { name: '💬 Total Messages', value: (channelMessages[0]?.count || 0).toLocaleString(), inline: true },
            { name: '👥 Unique Users', value: (uniqueUsers[0]?.count || 0).toLocaleString(), inline: true },
            { name: '📅 Period', value: `Last ${days} days`, inline: true }
          )
          .setFooter({ text: 'Server Stats Bot • QuantZen' })
          .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
        
      } else {
        // Top channels overview
        const channelStats = await db.getChannelStats(guild.id, days);
        
        if (channelStats.length === 0) {
          return interaction.editReply({
            content: '📊 No channel data available yet.'
          });
        }
        
        let channelsList = '';
        const totalMessages = channelStats.reduce((sum, ch) => sum + ch.message_count, 0);
        
        for (let i = 0; i < Math.min(10, channelStats.length); i++) {
          const ch = channelStats[i];
          const percentage = totalMessages > 0 ? ((ch.message_count / totalMessages) * 100).toFixed(1) : 0;
          const bar = '█'.repeat(Math.round(percentage / 5));
          channelsList += `<#${ch.channel_id}> \`${bar.padEnd(20)}\` **${ch.message_count.toLocaleString()}** (${percentage}%)\n`;
        }
        
        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle(`📁 Channel Activity - Last ${days} Days`)
          .setDescription(`**${guild.name}**\n\n${channelsList}`)
          .setFooter({ text: `Total: ${totalMessages.toLocaleString()} messages • Server Stats Bot • QuantZen` })
          .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
      }
      
    } catch (error) {
      console.error('Error in channelstats command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while fetching channel statistics.'
      });
    }
  }
};
