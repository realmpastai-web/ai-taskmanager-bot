const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('⚙️ Configure bot settings (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addBooleanOption(option =>
      option
        .setName('track_messages')
        .setDescription('Enable message tracking')
        .setRequired(false)
    )
    .addBooleanOption(option =>
      option
        .setName('track_voice')
        .setDescription('Enable voice tracking')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
      const trackMessages = interaction.options.getBoolean('track_messages');
      const trackVoice = interaction.options.getBoolean('track_voice');
      
      // Update settings in database
      const db = client.db;
      await db.run(
        `INSERT INTO guild_settings (guild_id, track_messages, track_voice) 
         VALUES (?, ?, ?)
         ON CONFLICT(guild_id) 
         DO UPDATE SET 
           track_messages = COALESCE(?, track_messages),
           track_voice = COALESCE(?, track_voice)`,
        [interaction.guild.id, trackMessages, trackVoice, trackMessages, trackVoice]
      );
      
      let updated = [];
      if (trackMessages !== null) updated.push(`Message tracking: ${trackMessages ? '✅ Enabled' : '❌ Disabled'}`);
      if (trackVoice !== null) updated.push(`Voice tracking: ${trackVoice ? '✅ Enabled' : '❌ Disabled'}`);
      
      await interaction.editReply({
        content: updated.length > 0 
          ? `⚙️ Settings updated:\n${updated.join('\n')}`
          : '⚙️ No changes made. Use the options to update settings.'
      });
      
    } catch (error) {
      console.error('Error in config command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while updating settings.'
      });
    }
  }
};
