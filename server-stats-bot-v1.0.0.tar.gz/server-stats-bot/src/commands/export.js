const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('export')
    .setDescription('📤 Export server data (Premium)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(option =>
      option
        .setName('type')
        .setDescription('Data to export')
        .setRequired(true)
        .addChoices(
          { name: 'Message Stats', value: 'messages' },
          { name: 'Member Growth', value: 'growth' },
          { name: 'User Activity', value: 'users' }
        )
    )
    .addStringOption(option =>
      option
        .setName('format')
        .setDescription('Export format')
        .setRequired(false)
        .addChoices(
          { name: 'CSV', value: 'csv' },
          { name: 'JSON', value: 'json' }
        )
    ),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
      // This is a premium feature placeholder
      // In production, this would generate actual CSV/JSON files
      
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('💎 Premium Feature')
        .setDescription('Data export is available with the **Premium** tier.\n\n**Premium includes:**\n📈 Unlimited historical data\n📊 PNG/PDF chart exports\n📤 CSV/JSON data exports\n🔔 Automated reports\n\n**Upgrade:** Contact admin or visit our website.')
        .setFooter({ text: 'Server Stats Bot • QuantZen' });
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Error in export command:', error);
      await interaction.editReply({
        content: '❌ An error occurred.'
      });
    }
  }
};
