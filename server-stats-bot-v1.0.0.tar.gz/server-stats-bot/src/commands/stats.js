const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('📊 View server statistics and key metrics'),

  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      const db = client.db;
      
      // Get server stats from database
      const stats = await db.getServerStats(guild.id);
      
      // Get current member count
      const memberCount = guild.memberCount;
      const botCount = guild.members.cache.filter(m => m.user.bot).size;
      const humanCount = memberCount - botCount;
      
      // Calculate boost level
      const boostLevel = guild.premiumTier;
      const boostCount = guild.premiumSubscriptionCount || 0;
      
      // Get top channel
      const channelStats = await db.getChannelStats(guild.id, 7);
      const topChannel = channelStats.length > 0 
        ? `<#${channelStats[0].channel_id}> (${channelStats[0].message_count} msgs)`
        : 'No data yet';
      
      // Create embed
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`📊 ${guild.name} Statistics`)
        .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
        .addFields(
          { 
            name: '👥 Members', 
            value: `**${memberCount.toLocaleString()}** total\n**${humanCount.toLocaleString()}** humans\n**${botCount.toLocaleString()}** bots`, 
            inline: true 
          },
          { 
            name: '💬 Messages', 
            value: `**${stats.totalMessages.toLocaleString()}** total\n**${stats.todayMessages.toLocaleString()}** today\n**${stats.avgDailyMessages.toLocaleString()}** avg/day`, 
            inline: true 
          },
          { 
            name: '📈 Activity', 
            value: `**${stats.activeUsers7d.toLocaleString()}** active (7d)\n🏆 ${topChannel}`, 
            inline: true 
          },
          { 
            name: '⚡ Server Boost', 
            value: `Level **${boostLevel}**\n**${boostCount}** boosts`, 
            inline: true 
          },
          { 
            name: '📅 Created', 
            value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, 
            inline: true 
          },
          { 
            name: '👑 Owner', 
            value: `<@${guild.ownerId}>`, 
            inline: true 
          }
        )
        .setFooter({ text: 'Server Stats Bot • QuantZen' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Error in stats command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while fetching statistics. Please try again later.'
      });
    }
  }
};
