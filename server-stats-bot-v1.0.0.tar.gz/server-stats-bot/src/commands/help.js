const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('❓ Show bot help and information'),

  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('📊 Server Stats Bot - Help')
      .setDescription('Professional Discord server analytics by **QuantZen**\nTrack member growth, message activity, and more!')
      .addFields(
        { 
          name: '📊 Analytics Commands', 
          value: '`/stats` - Server overview\n`/growth` - Member growth charts\n`/topusers` - Most active members\n`/channelstats` - Channel activity\n`/activity` - Activity heatmap',
          inline: false 
        },
        { 
          name: '⚙️ Admin Commands', 
          value: '`/export` - Export data (Premium)\n`/config` - Bot settings',
          inline: false 
        },
        { 
          name: '💎 Premium Features', 
          value: '• Unlimited historical data\n• PNG/PDF chart exports\n• Automated reports\n• API access\n\nContact us to upgrade!',
          inline: false 
        }
      )
      .setFooter({ text: 'Server Stats Bot v1.0.0 • QuantBitRealm Studios' })
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
};
