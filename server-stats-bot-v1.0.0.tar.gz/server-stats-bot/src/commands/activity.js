const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('activity')
    .setDescription('🔥 View server activity heatmap and trends'),

  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      const db = client.db;
      
      // Get hourly activity
      const hourlyData = await db.getActivityByHour(guild.id, 30);
      
      if (hourlyData.length === 0) {
        return interaction.editReply({
          content: '🔥 No activity data available yet. Data is collected as members chat.'
        });
      }
      
      // Build heatmap
      const hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
      const activityMap = {};
      
      hourlyData.forEach(row => {
        activityMap[row.hour] = row.count;
      });
      
      const maxCount = Math.max(...hourlyData.map(d => d.count), 1);
      
      // Create visual heatmap
      let morning = '';
      let afternoon = '';
      let evening = '';
      let night = '';
      
      for (let h = 0; h < 24; h++) {
        const hourStr = h.toString().padStart(2, '0');
        const count = activityMap[hourStr] || 0;
        const intensity = Math.min(4, Math.floor((count / maxCount) * 4));
        const blocks = ['⬛', '🟦', '🟩', '🟨', '🟥'];
        const block = blocks[intensity];
        
        const label = `\`${hourStr}:00\``;
        const line = `${label} ${block} ${count.toLocaleString().padStart(6)}\n`;
        
        if (h < 6) night += line;
        else if (h < 12) morning += line;
        else if (h < 18) afternoon += line;
        else evening += line;
      }
      
      // Get peak activity
      const peakHour = hourlyData.reduce((max, curr) => curr.count > max.count ? curr : max, hourlyData[0]);
      
      const embed = new EmbedBuilder()
        .setColor(0xFF6B35)
        .setTitle(`🔥 Activity Heatmap - ${guild.name}`)
        .setDescription(`**Peak Activity:** ${peakHour.hour}:00 (${peakHour.count.toLocaleString()} messages)\n**Data:** Last 30 days`)
        .addFields(
          { name: '🌅 Morning (6-12)', value: morning || 'No data', inline: true },
          { name: '☀️ Afternoon (12-18)', value: afternoon || 'No data', inline: true },
          { name: '🌆 Evening (18-24)', value: evening || 'No data', inline: true }
        )
        .addFields(
          { name: '🌙 Night (0-6)', value: night || 'No data', inline: false }
        )
        .setFooter({ text: 'Server Stats Bot • QuantZen' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Error in activity command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while fetching activity data.'
      });
    }
  }
};
