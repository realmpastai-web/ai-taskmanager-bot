const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('growth')
    .setDescription('📈 View member growth over time')
    .addStringOption(option =>
      option
        .setName('period')
        .setDescription('Time period to show')
        .setRequired(false)
        .addChoices(
          { name: '7 Days', value: '7' },
          { name: '30 Days', value: '30' },
          { name: '90 Days', value: '90' }
        )
    ),

  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      const db = client.db;
      const days = parseInt(interaction.options.getString('period') || '30');
      
      // Get growth data
      const growthData = await db.getMemberGrowth(guild.id, days);
      
      if (growthData.length === 0) {
        return interaction.editReply({
          content: '📊 No growth data available yet. Data is collected starting from when the bot was added.'
        });
      }
      
      const currentCount = guild.memberCount;
      const startCount = growthData[0]?.count || currentCount;
      const growth = currentCount - startCount;
      const growthPercent = startCount > 0 ? ((growth / startCount) * 100).toFixed(1) : 0;
      
      // Build trend visualization
      let trendText = '';
      const step = Math.max(1, Math.floor(growthData.length / 5));
      
      for (let i = 0; i < growthData.length; i += step) {
        const point = growthData[i];
        const date = new Date(point.date);
        const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const bar = '█'.repeat(Math.min(20, Math.max(1, (point.count / currentCount) * 20)));
        trendText += `\`${dateStr.padEnd(12)}\` ${bar} ${point.count}\n`;
      }
      
      const embed = new EmbedBuilder()
        .setColor(growth >= 0 ? 0x00FF88 : 0xFF4444)
        .setTitle(`📈 Member Growth - Last ${days} Days`)
        .setDescription(`**${guild.name}**\n\n**Current:** ${currentCount.toLocaleString()} members\n**Growth:** ${growth >= 0 ? '+' : ''}${growth.toLocaleString()} (${growthPercent}%)`)
        .addFields(
          { 
            name: '📊 Growth Trend', 
            value: trendText || 'Collecting data...', 
            inline: false 
          }
        )
        .setFooter({ text: 'Server Stats Bot • QuantZen' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [embed] });
      
    } catch (error) {
      console.error('Error in growth command:', error);
      await interaction.editReply({
        content: '❌ An error occurred while fetching growth data.'
      });
    }
  }
};
