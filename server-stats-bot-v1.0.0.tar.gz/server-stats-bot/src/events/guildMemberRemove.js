const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(member, client) {
    try {
      // Record new member count
      await client.db.recordMemberCount(member.guild.id, member.guild.memberCount);
      logger.info(`Member left: ${member.user.tag} from ${member.guild.name}`);
      
    } catch (error) {
      logger.error('Error tracking member leave:', error);
    }
  }
};
