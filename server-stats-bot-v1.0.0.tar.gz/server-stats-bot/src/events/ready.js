const { Events, ActivityType } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    logger.info(`Ready! Logged in as ${client.user.tag}`);
    
    // Set bot activity
    client.user.setActivity('/stats for analytics', { type: ActivityType.Watching });
    
    // Record initial member counts for all guilds
    for (const guild of client.guilds.cache.values()) {
      try {
        await client.db.recordMemberCount(guild.id, guild.memberCount);
        logger.info(`Recorded member count for ${guild.name}: ${guild.memberCount}`);
      } catch (error) {
        logger.error(`Failed to record stats for ${guild.name}:`, error);
      }
    }
    
    // Schedule periodic member count recording (every hour)
    setInterval(async () => {
      for (const guild of client.guilds.cache.values()) {
        try {
          await client.db.recordMemberCount(guild.id, guild.memberCount);
        } catch (error) {
          logger.error(`Failed to record member count for ${guild.name}:`, error);
        }
      }
    }, 60 * 60 * 1000); // Every hour
    
    logger.info('Bot is fully operational');
  }
};
