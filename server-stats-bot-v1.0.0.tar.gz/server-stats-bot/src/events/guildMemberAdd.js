const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member, client) {
    try {
      // Record new member count
      await client.db.recordMemberCount(member.guild.id, member.guild.memberCount);
      logger.info(`Member joined: ${member.user.tag} in ${member.guild.name}`);
      
      // Track user join in activity table
      await client.db.run(
        `INSERT INTO user_activity (guild_id, user_id, joined_at, last_active)
         VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
         ON CONFLICT(guild_id, user_id)
         DO UPDATE SET joined_at = CURRENT_TIMESTAMP`,
        [member.guild.id, member.user.id]
      );
      
    } catch (error) {
      logger.error('Error tracking member join:', error);
    }
  }
};
