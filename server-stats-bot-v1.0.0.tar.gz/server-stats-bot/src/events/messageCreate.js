const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    // Ignore bot messages and DMs
    if (message.author.bot || !message.guild) return;
    
    try {
      // Check if message tracking is enabled for this guild
      const settings = await client.db.get(
        'SELECT track_messages FROM guild_settings WHERE guild_id = ?',
        [message.guild.id]
      );
      
      // Default to tracking if not configured
      if (settings && settings.track_messages === 0) return;
      
      // Record message stats
      await client.db.recordMessage(
        message.guild.id,
        message.channel.id,
        message.author.id,
        message.content.length,
        message.attachments.size > 0
      );
      
    } catch (error) {
      logger.error('Error tracking message:', error);
    }
  }
};
