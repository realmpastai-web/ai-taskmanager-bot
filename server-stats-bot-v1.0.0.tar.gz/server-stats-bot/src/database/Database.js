const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

class Database {
  constructor(dbPath = './data/stats.db') {
    this.dbPath = dbPath;
    this.db = null;
  }

  async init() {
    // Ensure directory exists
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    return new Promise((resolve, reject) => {
      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          reject(err);
        } else {
          logger.info('Connected to SQLite database');
          this.createTables().then(resolve).catch(reject);
        }
      });
    });
  }

  async createTables() {
    const tables = [
      // Guild settings
      `CREATE TABLE IF NOT EXISTS guild_settings (
        guild_id TEXT PRIMARY KEY,
        track_messages INTEGER DEFAULT 1,
        track_voice INTEGER DEFAULT 1,
        track_invites INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Member snapshots
      `CREATE TABLE IF NOT EXISTS member_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        member_count INTEGER NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Message stats
      `CREATE TABLE IF NOT EXISTS message_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        message_length INTEGER DEFAULT 0,
        has_attachment INTEGER DEFAULT 0,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Voice stats
      `CREATE TABLE IF NOT EXISTS voice_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        join_time DATETIME NOT NULL,
        leave_time DATETIME,
        duration_seconds INTEGER DEFAULT 0
      )`,
      
      // Invite tracking
      `CREATE TABLE IF NOT EXISTS invite_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        invite_code TEXT NOT NULL,
        inviter_id TEXT,
        uses INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // User activity
      `CREATE TABLE IF NOT EXISTS user_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        messages_today INTEGER DEFAULT 0,
        messages_week INTEGER DEFAULT 0,
        messages_month INTEGER DEFAULT 0,
        last_active DATETIME,
        joined_at DATETIME,
        UNIQUE(guild_id, user_id)
      )`
    ];

    for (const table of tables) {
      await this.run(table);
    }
    
    // Create indexes
    await this.run('CREATE INDEX IF NOT EXISTS idx_snapshots_guild_time ON member_snapshots(guild_id, timestamp)');
    await this.run('CREATE INDEX IF NOT EXISTS idx_messages_guild ON message_stats(guild_id)');
    await this.run('CREATE INDEX IF NOT EXISTS idx_messages_user ON message_stats(guild_id, user_id)');
    await this.run('CREATE INDEX IF NOT EXISTS idx_voice_guild ON voice_stats(guild_id)');
    
    logger.info('Database tables initialized');
  }

  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
      });
    });
  }

  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  // Member count tracking
  async recordMemberCount(guildId, count) {
    return this.run(
      'INSERT INTO member_snapshots (guild_id, member_count) VALUES (?, ?)',
      [guildId, count]
    );
  }

  async getMemberGrowth(guildId, days = 30) {
    return this.all(
      `SELECT date(timestamp) as date, MAX(member_count) as count 
       FROM member_snapshots 
       WHERE guild_id = ? AND timestamp > datetime('now', '-${days} days')
       GROUP BY date(timestamp)
       ORDER BY date`,
      [guildId]
    );
  }

  // Message tracking
  async recordMessage(guildId, channelId, userId, messageLength, hasAttachment) {
    await this.run(
      'INSERT INTO message_stats (guild_id, channel_id, user_id, message_length, has_attachment) VALUES (?, ?, ?, ?, ?)',
      [guildId, channelId, userId, messageLength, hasAttachment ? 1 : 0]
    );
    
    // Update user activity
    await this.run(
      `INSERT INTO user_activity (guild_id, user_id, messages_today, messages_week, messages_month, last_active, joined_at)
       VALUES (?, ?, 1, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
       ON CONFLICT(guild_id, user_id) 
       DO UPDATE SET 
         messages_today = messages_today + 1,
         messages_week = messages_week + 1,
         messages_month = messages_month + 1,
         last_active = CURRENT_TIMESTAMP`,
      [guildId, userId]
    );
  }

  async getTopUsers(guildId, limit = 10, period = 'all') {
    let timeFilter = '';
    if (period === 'day') timeFilter = "AND timestamp > datetime('now', '-1 day')";
    else if (period === 'week') timeFilter = "AND timestamp > datetime('now', '-7 days')";
    else if (period === 'month') timeFilter = "AND timestamp > datetime('now', '-30 days')";
    
    return this.all(
      `SELECT user_id, COUNT(*) as message_count 
       FROM message_stats 
       WHERE guild_id = ? ${timeFilter}
       GROUP BY user_id 
       ORDER BY message_count DESC 
       LIMIT ?`,
      [guildId, limit]
    );
  }

  async getChannelStats(guildId, days = 30) {
    return this.all(
      `SELECT channel_id, COUNT(*) as message_count 
       FROM message_stats 
       WHERE guild_id = ? AND timestamp > datetime('now', '-${days} days')
       GROUP BY channel_id 
       ORDER BY message_count DESC`,
      [guildId]
    );
  }

  async getActivityByHour(guildId, days = 7) {
    return this.all(
      `SELECT strftime('%H', timestamp) as hour, COUNT(*) as count 
       FROM message_stats 
       WHERE guild_id = ? AND timestamp > datetime('now', '-${days} days')
       GROUP BY hour 
       ORDER BY hour`,
      [guildId]
    );
  }

  // Stats summary
  async getServerStats(guildId) {
    const totalMessages = await this.get(
      'SELECT COUNT(*) as count FROM message_stats WHERE guild_id = ?',
      [guildId]
    );
    
    const todayMessages = await this.get(
      "SELECT COUNT(*) as count FROM message_stats WHERE guild_id = ? AND date(timestamp) = date('now')",
      [guildId]
    );
    
    const activeUsers = await this.get(
      "SELECT COUNT(DISTINCT user_id) as count FROM message_stats WHERE guild_id = ? AND timestamp > datetime('now', '-7 days')",
      [guildId]
    );
    
    const avgMessages = await this.get(
      `SELECT AVG(daily_count) as avg FROM (
        SELECT date(timestamp) as date, COUNT(*) as daily_count 
        FROM message_stats 
        WHERE guild_id = ? AND timestamp > datetime('now', '-30 days')
        GROUP BY date(timestamp)
      )`,
      [guildId]
    );
    
    return {
      totalMessages: totalMessages?.count || 0,
      todayMessages: todayMessages?.count || 0,
      activeUsers7d: activeUsers?.count || 0,
      avgDailyMessages: Math.round(avgMessages?.avg || 0)
    };
  }

  async close() {
    return new Promise((resolve) => {
      if (this.db) {
        this.db.close((err) => {
          if (err) logger.error('Error closing database:', err);
          else logger.info('Database connection closed');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

module.exports = Database;
