# Server Stats Bot - Discord Analytics

Professional Discord server analytics bot that tracks member growth, message activity, channel statistics, and generates beautiful reports.

## ✨ Features

### 📊 Core Analytics
- **Member Growth Tracking** - Daily, weekly, monthly growth charts
- **Message Activity** - Messages per channel, per user, hourly trends
- **Voice Activity** - Voice channel usage statistics
- **Invite Tracking** - Track which invites bring the most members
- **Retention Metrics** - Member churn and engagement analysis

### 🤖 Slash Commands
| Command | Description | Permission |
|---------|-------------|------------|
| `/stats` | Server overview with key metrics | Everyone |
| `/activity` | Message activity heatmap and trends | Everyone |
| `/growth` | Member growth charts (7/30/90 days) | Everyone |
| `/topusers` | Most active members leaderboard | Everyone |
| `/channelstats` | Channel-specific analytics | Everyone |
| `/export` | Export data to CSV/JSON (Premium) | Administrator |
| `/invitestats` | Track invite conversions | Administrator |
| `/config` | Configure analytics settings | Administrator |

### 💎 Premium Features
- 📈 Unlimited historical data (Free: 7 days, Premium: 365+ days)
- 📊 PNG/PDF chart exports
- 🔗 Advanced invite tracking with conversion rates
- 📧 Automated weekly/monthly reports
- 🔔 Custom alert thresholds
- 🔗 API access for external dashboards

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Discord Developer account

### 1. Create Discord Application
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **New Application** → Name it "Server Stats"
3. Go to **Bot** tab → Click **Add Bot**
4. Enable Privileged Intents:
   - ✅ Server Members Intent
   - ✅ Message Content Intent
5. Copy your **Bot Token** (keep it secret!)
6. Go to **OAuth2** → Copy **Client ID**

### 2. Install & Configure

```bash
# Clone and navigate
cd server-stats-bot

# Install dependencies
npm install

# Configure environment
cp .env.example .env
```

Edit `.env` with your values:
```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here
```

### 3. Deploy Commands
```bash
npm run deploy-commands
```

### 4. Start the Bot
```bash
npm start
```

---

## 🐳 Docker Deployment

```bash
# One-command deploy
docker-compose up -d --build

# View logs
docker-compose logs -f
```

---

## 🔗 Invite URL

```
https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=66560&scope=bot%20applications.commands
```

**Required Permissions:**
- View Channels
- Read Message History
- Read Message Content (for analytics)

---

## 💰 Pricing

| Tier | Price | Features |
|------|-------|----------|
| **Free** | $0 | 7-day history, basic stats, standard charts |
| **Premium** | $10/mo | 365-day history, exports, invite tracking, reports |
| **Enterprise** | $50/mo | Unlimited history, API access, custom dashboards |

---

## 📁 Project Structure

```
server-stats-bot/
├── src/
│   ├── commands/        # Slash commands
│   ├── events/          # Event handlers
│   ├── services/        # Analytics services
│   ├── database/        # SQLite wrapper
│   └── utils/           # Helpers
├── data/                # Database files
├── docker-compose.yml
└── README.md
```

---

## 🛠️ Support

- **GitHub Issues:** https://github.com/quantbitrealmSimon/discord-bots/issues
- **Discord:** [QuantZen Server](https://discord.gg/quantzen)

---

Built with 📊 by QuantZen | QuantBitRealm Studios
