# Gumroad Listing - ServerStats Pro

## Product Title
ServerStats Pro - Discord Server Analytics & Growth Tracking Bot

## Short Description
Professional Discord analytics bot with member growth tracking, message statistics, and beautiful ASCII charts. Complete source code + deployment guide.

## Price
$150 (One-time purchase)

## Full Description

📊 **Know Your Community Inside and Out**

ServerStats Pro gives you powerful analytics for your Discord server. Track member growth, monitor activity trends, identify your most engaged users, and export data for deeper analysis. All with beautiful text-based charts that work right in Discord.

---

## ✨ What's Included

- ✅ **Complete Source Code** - Fully documented TypeScript/Discord.js v14 codebase
- ✅ **6 Analytics Commands** - stats, activity, growth, topusers, export, help
- ✅ **SQLite Database** - Efficient data storage with WAL mode
- ✅ **Visual Charts** - ASCII-based activity graphs in Discord
- ✅ **Data Export** - CSV and JSON export for admins
- ✅ **Docker Setup** - One-command deployment
- ✅ **Railway Config** - Cloud deployment ready
- ✅ **Full Documentation** - Setup guide and command reference
- ✅ **6 Months Support** - Bug fixes and deployment help

---

## 🚀 Features

### Analytics Commands
| Command | Description |
|---------|-------------|
| `/stats` | Server overview with top channels & users |
| `/activity` [days] | Daily activity with visual charts |
| `/growth` | 30-day member growth trends |
| `/topusers` [limit] | Most active members leaderboard |
| `/export` <format> | Export data as CSV/JSON (Admin) |
| `/help` | Command reference |

### Data Tracking
- Message count per user and channel
- Member join/leave monitoring
- Daily activity snapshots
- 30-day historical data
- Top channels and users

### Visual Charts
- ASCII-based bar charts
- Activity trend visualization
- Growth trajectory graphs
- All displayed in Discord

---

## 💻 Tech Stack

- **Runtime:** Node.js 20+
- **Framework:** Discord.js v14
- **Language:** TypeScript
- **Database:** SQLite (better-sqlite3)
- **Charts:** ASCII text-based
- **Deployment:** Docker, Railway, PM2

---

## 📦 What You Get

```
server-stats-pro/
├── src/
│   ├── commands/          # 6 analytics commands
│   ├── events/            # Message & member tracking
│   ├── database/          # SQLite repository
│   ├── services/          # Chart & export services
│   ├── utils/             # Formatters & logger
│   ├── types/             # TypeScript definitions
│   ├── index.ts           # Main entry
│   └── deploy-commands.ts # Slash command deployer
├── Dockerfile
├── docker-compose.yml
├── railway.json
├── tsconfig.json
├── .env.example
├── README.md
├── DEPLOY.md
└── package.json
```

---

## 🎯 Perfect For

- Community managers
- Discord server owners
- NFT & crypto projects
- Gaming communities
- Content creators
- Marketing teams

---

## 🚀 Quick Deploy Options

### Railway (Easiest - 2 minutes)
1. Connect GitHub repo to Railway
2. Add environment variables
3. Deploy automatically

### Docker
```bash
docker-compose up -d
```

### VPS with PM2
```bash
npm install
npm run build
pm2 start dist/index.js --name "server-stats"
```

---

## 📋 Requirements

- Discord Developer Account (free)
- Node.js 20+ OR Docker
- Server with "View Channels" permission

---

## 🎓 Setup Instructions

1. Create Discord application at https://discord.com/developers/applications
2. Enable intents: SERVER MEMBERS, MESSAGE CONTENT
3. Invite bot to your server
4. Deploy using Railway/Docker/PM2
5. Start tracking with `/stats` command

Full setup guide in DEPLOY.md

---

## 💰 Pricing

**Personal License: $150**
- Use on your own servers
- Modify for personal use
- 6 months support

**Commercial License: +$100**
- Use for clients
- Resell the bot
- White-label rights
- Priority support

---

## 🔒 License & Terms

- Personal License: For personal/non-commercial use
- Commercial License: For commercial/client use
- No refunds after code delivery
- Support covers bug fixes, not customization

---

## 📞 Support

- **Email:** quantbitrealm@gmail.com
- **GitHub:** github.com/realmpastai-web
- **Response Time:** Within 24 hours

---

## 🌟 Why Choose ServerStats Pro?

1. **Beautiful Charts** - Visual analytics in Discord
2. **Easy Deploy** - Docker + Railway configs included
3. **Export Data** - CSV/JSON for external analysis
4. **Lightweight** - SQLite, no external DB needed
5. **TypeScript** - Type-safe, maintainable code
6. **Affordable** - One-time payment, no monthly fees

---

**Start tracking your community growth today! 📈**

---

## SEO Tags
discord analytics, server stats, community management, discord bot, member tracking, activity monitoring, discord.js, server growth, community analytics, engagement tracking, typescript bot

## Category
Software > Developer Tools

## URL Slug
serverstats-pro-discord-analytics
