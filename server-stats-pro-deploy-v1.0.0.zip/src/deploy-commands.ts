import { REST, Routes } from 'discord.js';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { logger } from './utils/logger';

dotenv.config();

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;

if (!token || !clientId) {
  console.error('Missing required environment variables: DISCORD_TOKEN and CLIENT_ID');
  process.exit(1);
}

const commands: any[] = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js') || file.endsWith('.ts'));

// Load all commands
for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath).default;
  
  if ('data' in command && 'execute' in command) {
    commands.push(command.data.toJSON());
    logger.info(`Prepared command for deployment: ${command.data.name}`);
  } else {
    console.log(`[WARNING] Command at ${filePath} is missing required properties`);
  }
}

// Deploy commands
const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`Started refreshing ${commands.length} application (/) commands.`);

    // Global commands
    const data: any = await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands }
    );

    console.log(`Successfully reloaded ${data.length} application (/) commands.`);
    logger.info(`Deployed ${data.length} commands globally`);
  } catch (error) {
    console.error('Error deploying commands:', error);
    logger.error('Command deployment failed:', error);
  }
})();