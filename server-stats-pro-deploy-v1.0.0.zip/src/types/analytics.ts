export interface MemberStats {
  id?: number;
  guild_id: string;
  user_id: string;
  username: string;
  message_count: number;
  character_count: number;
  voice_minutes: number;
  joined_at?: number;
  last_active?: number;
}

export interface MessageActivity {
  id?: number;
  guild_id: string;
  channel_id: string;
  user_id: string;
  message_count: number;
  character_count: number;
  date: number;
  total_messages?: number;
  active_users?: number;
}

export interface ChannelStats {
  id?: number;
  guild_id: string;
  channel_id: string;
  channel_name: string;
  message_count: number;
  date: number;
}

export interface MemberEvent {
  id?: number;
  guild_id: string;
  user_id: string;
  username: string;
  event_type: 'join' | 'leave';
  event_date: number;
}

export interface DailySnapshot {
  id?: number;
  guild_id: string;
  snapshot_date: number;
  member_count: number;
  message_count: number;
  active_users: number;
}

export interface ServerStats {
  totalMessages: number;
  activeUsers24h: number;
  activeUsers7d: number;
  joins: number;
  leaves: number;
}

export interface GrowthData {
  labels: string[];
  memberCounts: number[];
  messageCounts: number[];
  activeUsers: number[];
}