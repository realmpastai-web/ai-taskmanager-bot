import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { AnalyticsRepository } from '../../database/repository';
import { ChartService } from '../../services/chartService';
import { formatNumber, formatShortDate } from '../../utils/formatters';

export default {
  data: new SlashCommandBuilder()
    .setName('growth')
    .setDescription('View server growth charts and member trends'),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    
    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply('This command can only be used in a server.');
      return;
    }

    const snapshots = AnalyticsRepository.getSnapshots(guild.id, 30);
    const memberEvents = AnalyticsRepository.getMemberEvents(guild.id, 30);

    // Generate growth text chart
    const chartText = ChartService.generateGrowthTextChart(snapshots);

    // Calculate growth metrics
    const currentMembers = guild.memberCount;
    const growth30d = memberEvents.joins - memberEvents.leaves;
    const growthRate = snapshots.length > 1 && snapshots[0].member_count > 0
      ? ((currentMembers - snapshots[0].member_count) / snapshots[0].member_count * 100).toFixed(1)
      : '0.0';

    const embed = new EmbedBuilder()
      .setTitle(`📈 ${guild.name} Growth Analytics`)
      .setColor('#5865F2')
      .setDescription(chartText)
      .addFields(
        { 
          name: '👥 Current Statistics', 
          value: `
• Total Members: **${formatNumber(currentMembers)}**
• Growth (30d): **${growth30d > 0 ? '+' : ''}${formatNumber(growth30d)}**
• Growth Rate: **${growthRate}%**
`,
          inline: true 
        },
        { 
          name: '📊 Activity (30d)', 
          value: `
• New Joins: **${formatNumber(memberEvents.joins)}**
• Leaves: **${formatNumber(memberEvents.leaves)}**
• Net Growth: **${growth30d > 0 ? '+' : ''}${formatNumber(growth30d)}**
`,
          inline: true 
        }
      )
      .setFooter({ text: 'ServerStats Pro • Growth Tracking' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};
