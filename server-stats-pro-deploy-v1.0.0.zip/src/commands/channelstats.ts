import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { AnalyticsRepository } from '../../database/repository';
import { formatNumber, createProgressBar } from '../../utils/formatters';

export default {
  data: new SlashCommandBuilder()
    .setName('channelstats')
    .setDescription('View channel activity statistics')
    .addStringOption(option =>
      option
        .setName('period')
        .setDescription('Time period')
        .setRequired(false)
        .addChoices(
          { name: 'Last 7 days', value: '7' },
          { name: 'Last 14 days', value: '14' },
          { name: 'Last 30 days', value: '30' }
        )
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    
    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply('This command can only be used in a server.');
      return;
    }

    const days = parseInt(interaction.options.getString('period') || '7');
    const channelStats = AnalyticsRepository.getTopChannels(guild.id, days, 15);

    if (channelStats.length === 0) {
      await interaction.editReply('No channel data available yet. Activity will be tracked from now on!');
      return;
    }

    const totalMessages = channelStats.reduce((sum, c) => sum + c.message_count, 0);
    const maxMessages = channelStats[0].message_count;

    const embed = new EmbedBuilder()
      .setTitle(`📊 Channel Statistics`)
      .setDescription(`Server: **${guild.name}**\nPeriod: **Last ${days} days**`)
      .setColor('#eb459e')
      .addFields({
        name: 'Total Messages',
        value: formatNumber(totalMessages),
        inline: true
      });

    const channelList = channelStats.map((channel, index) => {
      const percentage = ((channel.message_count / totalMessages) * 100).toFixed(1);
      const bar = createProgressBar(channel.message_count, maxMessages, 12);
      return `#${index + 1} **#${channel.channel_name}**\n   ${bar} ${formatNumber(channel.message_count)} (${percentage}%)`;
    }).join('\n\n');

    embed.addFields({
      name: 'Channel Activity',
      value: channelList.slice(0, 1024) // Discord embed field limit
    });

    embed.setFooter({ text: 'ServerStats Pro • Channel Analytics' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};