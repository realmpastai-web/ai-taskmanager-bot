import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Display help information about the bot'),

  async execute(interaction: ChatInputCommandInteraction) {
    const embed = new EmbedBuilder()
      .setTitle('📊 ServerStats Pro - Help')
      .setDescription('Advanced Discord Server Analytics Bot')
      .setColor('#5865F2')
      .addFields(
        {
          name: '📈 Analytics Commands',
          value: `
**\`/stats\`** - View comprehensive server statistics
**\`/activity\`** - View daily activity charts
**\`/growth\`** - View server growth over time
**\`/topusers\`** - View most active users leaderboard
**\`/channelstats\`** - View channel activity statistics
`
        },
        {
          name: '💾 Data Management',
          value: `
**\`/export\`** - Export analytics data (Admin only)
  • Supports CSV and JSON formats
  • Export user, channel, or activity data
`
        },
        {
          name: '🤖 Bot Features',
          value: `
• Real-time message tracking
• Member join/leave monitoring
• Voice channel activity tracking
• Daily automated snapshots
• Growth charts and visualizations
• Data export capabilities
`
        },
        {
          name: '⚙️ Setup',
          value: `
1. Ensure bot has \`Read Message History\` permission
2. Bot tracks data automatically after joining
3. Use commands to view statistics anytime
4. Export data for external analysis
`
        }
      )
      .setFooter({ text: 'ServerStats Pro v1.0.0 • Premium Analytics Bot' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};