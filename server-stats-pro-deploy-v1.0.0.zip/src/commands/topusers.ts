import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { AnalyticsRepository } from '../../database/repository';
import { formatNumber, createProgressBar } from '../../utils/formatters';

export default {
  data: new SlashCommandBuilder()
    .setName('topusers')
    .setDescription('View top users by message count')
    .addIntegerOption(option =>
      option
        .setName('limit')
        .setDescription('Number of users to show')
        .setRequired(false)
        .setMinValue(5)
        .setMaxValue(25)
    )
    .addStringOption(option =>
      option
        .setName('period')
        .setDescription('Time period')
        .setRequired(false)
        .addChoices(
          { name: 'All time', value: 'all' },
          { name: 'Last 7 days', value: '7' },
          { name: 'Last 30 days', value: '30' }
        )
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    
    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply('This command can only be used in a server.');
      return;
    }

    const limit = interaction.options.getInteger('limit') || 10;
    const topUsers = AnalyticsRepository.getTopUsers(guild.id, limit);

    if (topUsers.length === 0) {
      await interaction.editReply('No user data available yet. Messages will be tracked from now on!');
      return;
    }

    const maxMessages = topUsers[0].message_count;

    const embed = new EmbedBuilder()
      .setTitle(`🏆 Top ${limit} Most Active Users`)
      .setDescription(`Server: **${guild.name}**`)
      .setColor('#f1c40f')
      .setThumbnail(guild.iconURL({ size: 128 }) || null);

    const userList = topUsers.map((user, index) => {
      const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`;
      const bar = createProgressBar(user.message_count, maxMessages, 15);
      return `${medal} **${user.username}**\n   ${bar} ${formatNumber(user.message_count)} msgs`;
    }).join('\n\n');

    embed.addFields({
      name: 'Leaderboard',
      value: userList || 'No data available'
    });

    embed.setFooter({ text: 'ServerStats Pro • Rankings update in real-time' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};