import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits } from 'discord.js';
import { AnalyticsRepository } from '../../database/repository';
import { format } from 'date-fns';
import fs from 'fs';
import path from 'path';

export default {
  data: new SlashCommandBuilder()
    .setName('export')
    .setDescription('Export server analytics data (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(option =>
      option
        .setName('format')
        .setDescription('Export format')
        .setRequired(false)
        .addChoices(
          { name: 'CSV', value: 'csv' },
          { name: 'JSON', value: 'json' }
        )
    )
    .addStringOption(option =>
      option
        .setName('data')
        .setDescription('Type of data to export')
        .setRequired(false)
        .addChoices(
          { name: 'User Statistics', value: 'users' },
          { name: 'Channel Statistics', value: 'channels' },
          { name: 'Message Activity', value: 'activity' },
          { name: 'All Data', value: 'all' }
        )
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    
    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply('This command can only be used in a server.');
      return;
    }

    const format_type = interaction.options.getString('format') || 'csv';
    const data_type = interaction.options.getString('data') || 'all';
    
    try {
      let content = '';
      let filename = '';
      const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm');

      if (format_type === 'csv') {
        if (data_type === 'users' || data_type === 'all') {
          const users = AnalyticsRepository.getTopUsers(guild.id, 1000);
          filename = `user_stats_${guild.id}_${timestamp}.csv`;
          content = 'User ID,Username,Message Count,Character Count,Last Active\n';
          content += users.map(u => 
            `"${u.user_id}","${u.username}",${u.message_count},${u.character_count},"${u.last_active || 'Never'}"`
          ).join('\n');
        } else if (data_type === 'channels') {
          const channels = AnalyticsRepository.getTopChannels(guild.id, 30, 1000);
          filename = `channel_stats_${guild.id}_${timestamp}.csv`;
          content = 'Channel ID,Channel Name,Message Count\n';
          content += channels.map(c => 
            `"${c.channel_id}","${c.channel_name}",${c.message_count}`
          ).join('\n');
        }
      } else {
        // JSON export
        const exportData: any = {
          guild_id: guild.id,
          guild_name: guild.name,
          exported_at: new Date().toISOString(),
          data: {}
        };

        if (data_type === 'users' || data_type === 'all') {
          exportData.data.users = AnalyticsRepository.getTopUsers(guild.id, 1000);
        }
        if (data_type === 'channels' || data_type === 'all') {
          exportData.data.channels = AnalyticsRepository.getTopChannels(guild.id, 30, 1000);
        }
        if (data_type === 'activity' || data_type === 'all') {
          exportData.data.activity = AnalyticsRepository.getDailyStats(guild.id, 30);
        }

        filename = `analytics_${guild.id}_${timestamp}.json`;
        content = JSON.stringify(exportData, null, 2);
      }

      // Write to temp file
      const tempDir = './temp';
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      const filePath = path.join(tempDir, filename);
      fs.writeFileSync(filePath, content);

      await interaction.editReply({
        content: `📁 Here is your ${data_type} data export in ${format_type.toUpperCase()} format:`,
        files: [filePath]
      });

      // Clean up temp file after sending
      setTimeout(() => {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          // Ignore cleanup errors
        }
      }, 60000);

    } catch (error) {
      console.error('Export error:', error);
      await interaction.editReply('❌ An error occurred while exporting data. Please try again later.');
    }
  }
};