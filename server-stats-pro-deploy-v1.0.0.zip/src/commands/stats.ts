import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { AnalyticsRepository } from '../../database/repository';
import { formatNumber } from '../../utils/formatters';

export default {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View comprehensive server statistics'),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();
    
    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply('This command can only be used in a server.');
      return;
    }

    const stats = AnalyticsRepository.getServerStats(guild.id);
    const topChannels = AnalyticsRepository.getTopChannels(guild.id, 7, 5);
    const topUsers = AnalyticsRepository.getTopUsers(guild.id, 5);

    const embed = new EmbedBuilder()
      .setTitle(`📊 ${guild.name} Statistics`)
      .setColor('#5865F2')
      .setThumbnail(guild.iconURL({ size: 128 }) || null)
      .addFields(
        { 
          name: '👥 Members', 
          value: `
• Total: **${formatNumber(guild.memberCount)}**
• Active (24h): **${formatNumber(stats.activeUsers24h)}**
• Active (7d): **${formatNumber(stats.activeUsers7d)}**
`,
          inline: true 
        },
        { 
          name: '📨 Messages', 
          value: `
• Total: **${formatNumber(stats.totalMessages)}**
• Joins (7d): **+${formatNumber(stats.joins)}**
• Leaves (7d): **-${formatNumber(stats.leaves)}**
`,
          inline: true 
        },
        { 
          name: '🏆 Top Channels (7d)', 
          value: topChannels.length > 0 
            ? topChannels.map((c, i) => `${i + 1}. #${c.channel_name} (${formatNumber(c.message_count)})`).join('\n')
            : 'No data yet',
          inline: false 
        },
        { 
          name: '🔥 Most Active Users (All time)', 
          value: topUsers.length > 0 
            ? topUsers.map((u, i) => `${i + 1}. ${u.username} (${formatNumber(u.message_count)} msgs)`).join('\n')
            : 'No data yet',
          inline: false 
        }
      )
      .setFooter({ text: 'ServerStats Pro • Use /help for more commands' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
};