import { Events, GuildMember } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';

export default {
  name: Events.GuildMemberAdd,
  async execute(member: GuildMember) {
    try {
      await AnalyticsService.trackMemberJoin(member.guild, member.user);
    } catch (error) {
      logger.error('Error handling member join:', error);
    }
  }
};