import { Events, GuildMember } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';

export default {
  name: Events.GuildMemberRemove,
  async execute(member: GuildMember) {
    try {
      await AnalyticsService.trackMemberLeave(member.guild, member.user);
    } catch (error) {
      logger.error('Error handling member leave:', error);
    }
  }
};