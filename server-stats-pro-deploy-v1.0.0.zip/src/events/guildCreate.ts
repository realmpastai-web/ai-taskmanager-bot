import { Events, Guild } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';

export default {
  name: Events.GuildCreate,
  async execute(guild: Guild) {
    try {
      logger.info(`Joined new guild: ${guild.name} (${guild.id})`);
      await AnalyticsService.initializeGuild(guild);
    } catch (error) {
      logger.error('Error handling guild create:', error);
    }
  }
};