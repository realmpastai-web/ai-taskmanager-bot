import { Events, VoiceState, ChannelType } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';

export default {
  name: Events.VoiceStateUpdate,
  async execute(oldState: VoiceState, newState: VoiceState) {
    try {
      const guildId = oldState.guild.id || newState.guild.id;
      const userId = oldState.member?.user.id || newState.member?.user.id;
      if (!userId) return;
      
      if (!oldState.channel && newState.channel) {
        if (newState.channel.type === ChannelType.GuildVoice) {
          await AnalyticsService.startVoiceSession(guildId, newState.channel.id, userId);
        }
      }
      
      if (oldState.channel && !newState.channel) {
        await AnalyticsService.endVoiceSession(guildId, userId);
      }
      
      if (oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id) {
        await AnalyticsService.endVoiceSession(guildId, userId);
        if (newState.channel.type === ChannelType.GuildVoice) {
          await AnalyticsService.startVoiceSession(guildId, newState.channel.id, userId);
        }
      }
    } catch (error) {
      logger.error('Error handling voice state update:', error);
    }
  }
};