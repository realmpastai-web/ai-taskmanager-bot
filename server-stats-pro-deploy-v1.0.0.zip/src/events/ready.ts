import { Events, Client, ActivityType } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';
import { initializeDatabase } from '../database/connection';

export default {
  name: Events.ClientReady,
  once: true,
  async execute(client: Client) {
    if (!client.user) {
      logger.error('Client user is null');
      return;
    }

    logger.info(`Ready! Logged in as ${client.user.tag}`);
    initializeDatabase();
    client.user.setActivity('server analytics | /stats', { type: ActivityType.Watching });
    
    const guilds = client.guilds.cache;
    logger.info(`Bot is in ${guilds.size} guild(s)`);
    
    for (const [, guild] of guilds) {
      try {
        await AnalyticsService.initializeGuild(guild);
      } catch (error) {
        logger.error(`Failed to initialize guild ${guild.name}:`, error);
      }
    }
    
    setInterval(async () => {
      const now = new Date();
      if (now.getUTCHours() === 0) {
        for (const [, guild] of client.guilds.cache) {
          await AnalyticsService.createDailySnapshot(guild);
        }
      }
    }, 60 * 60 * 1000);
    
    logger.info('Bot initialization complete');
  }
};