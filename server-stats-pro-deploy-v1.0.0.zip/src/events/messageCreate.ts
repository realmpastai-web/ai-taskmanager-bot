import { Events, Message, ChannelType } from 'discord.js';
import { AnalyticsService } from '../services/analyticsService';
import { logger } from '../utils/logger';

export default {
  name: Events.MessageCreate,
  async execute(message: Message) {
    if (message.author.bot) return;
    if (!message.guild || message.channel.type !== ChannelType.GuildText) return;
    
    try {
      await AnalyticsService.trackMessage(
        message.guild.id,
        message.channel.id,
        message.channel.name,
        message.author.id,
        message.author.tag,
        message.content
      );
    } catch (error) {
      logger.error('Error handling message create:', error);
    }
  }
};