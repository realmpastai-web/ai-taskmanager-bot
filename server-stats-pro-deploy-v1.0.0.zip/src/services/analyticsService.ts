import { AnalyticsRepository } from '../database/repository';
import { Guild, TextChannel, User } from 'discord.js';
import { logger } from '../utils/logger';

export class AnalyticsService {
  static async trackMessage(guildId: string, channelId: string, channelName: string, userId: string, username: string, content: string): Promise<void> {
    try {
      const charCount = content.length;
      AnalyticsRepository.incrementMessageCount(guildId, userId, username, charCount);
      AnalyticsRepository.recordChannelMessage(guildId, channelId, channelName);
      AnalyticsRepository.recordMessageActivity(guildId, channelId, userId, charCount);
      logger.debug(`Tracked message from ${username} in ${channelName}`);
    } catch (error) {
      logger.error('Error tracking message:', error);
    }
  }

  static async trackMemberJoin(guild: Guild, user: User): Promise<void> {
    try {
      AnalyticsRepository.recordMemberEvent(guild.id, user.id, user.tag, 'join');
      AnalyticsRepository.upsertGuild(guild.id, guild.name);
      logger.info(`Member joined: ${user.tag} in ${guild.name}`);
    } catch (error) {
      logger.error('Error tracking member join:', error);
    }
  }

  static async trackMemberLeave(guild: Guild, user: User): Promise<void> {
    try {
      AnalyticsRepository.recordMemberEvent(guild.id, user.id, user.tag, 'leave');
      logger.info(`Member left: ${user.tag} from ${guild.name}`);
    } catch (error) {
      logger.error('Error tracking member leave:', error);
    }
  }

  static async startVoiceSession(guildId: string, channelId: string, userId: string): Promise<void> {
    try {
      AnalyticsRepository.startVoiceSession(guildId, channelId, userId);
      logger.debug(`Voice session started for ${userId}`);
    } catch (error) {
      logger.error('Error starting voice session:', error);
    }
  }

  static async endVoiceSession(guildId: string, userId: string): Promise<void> {
    try {
      AnalyticsRepository.endVoiceSession(guildId, userId);
      logger.debug(`Voice session ended for ${userId}`);
    } catch (error) {
      logger.error('Error ending voice session:', error);
    }
  }

  static async createDailySnapshot(guild: Guild): Promise<void> {
    try {
      const memberCount = guild.memberCount;
      const stats = AnalyticsRepository.getServerStats(guild.id);
      AnalyticsRepository.createSnapshot(guild.id, memberCount, stats.totalMessages, stats.activeUsers7d);
      logger.info(`Created daily snapshot for ${guild.name}: ${memberCount} members`);
    } catch (error) {
      logger.error('Error creating daily snapshot:', error);
    }
  }

  static async initializeGuild(guild: Guild): Promise<void> {
    try {
      AnalyticsRepository.upsertGuild(guild.id, guild.name);
      await this.createDailySnapshot(guild);
      logger.info(`Initialized analytics for guild: ${guild.name}`);
    } catch (error) {
      logger.error('Error initializing guild:', error);
    }
  }
}