import { DailySnapshot } from '../types/analytics';
import { logger } from '../utils/logger';

export class ChartService {
  /**
   * Generate a text-based ASCII chart for growth data
   */
  static generateGrowthTextChart(snapshots: DailySnapshot[]): string {
    if (snapshots.length < 2) {
      return 'Not enough data to generate chart.';
    }

    const labels = snapshots.map(s => {
      const date = new Date(s.snapshot_date * 1000);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    });

    const memberData = snapshots.map(s => s.member_count);
    const maxMembers = Math.max(...memberData);
    const minMembers = Math.min(...memberData);
    const range = maxMembers - minMembers || 1;

    // Create simple bar chart using Unicode blocks
    const chartHeight = 10;
    let chart = '```\n';
    chart += '📈 Server Growth (Last 30 Days)\n';
    chart += 'Members  │\n';

    for (let i = chartHeight; i >= 0; i--) {
      const threshold = minMembers + (range * i / chartHeight);
      let line = `${Math.round(threshold).toString().padStart(8)} │`;
      
      for (const count of memberData) {
        line += count >= threshold ? ' █' : '  ';
      }
      chart += line + '\n';
    }

    chart += '         └' + '──'.repeat(memberData.length) + '\n';
    chart += '          ' + labels.map(l => l.slice(0, 2).padStart(2)).join(' ') + '\n';
    chart += '```';

    return chart;
  }

  /**
   * Generate a text-based ASCII chart for activity data
   */
  static generateActivityTextChart(dailyData: any[]): string {
    if (dailyData.length === 0) {
      return 'No activity data available.';
    }

    const labels = dailyData.map(d => d.day.slice(5)); // MM-DD
    const messages = dailyData.map(d => d.messages);
    const maxMessages = Math.max(...messages) || 1;

    const chartHeight = 8;
    let chart = '```\n';
    chart += '📊 Daily Activity (Messages)\n';
    chart += 'Msgs  │\n';

    for (let i = chartHeight; i >= 0; i--) {
      const threshold = maxMessages * i / chartHeight;
      let line = `${Math.round(threshold).toString().padStart(5)} │`;
      
      for (const count of messages) {
        line += count >= threshold ? ' ▓' : '  ';
      }
      chart += line + '\n';
    }

    chart += '      └' + '──'.repeat(messages.length) + '\n';
    chart += '       ' + labels.map(l => l.slice(3).padStart(2)).join(' ') + '\n';
    chart += '```';

    return chart;
  }

  /**
   * Generate a simple progress bar
   */
  static generateProgressBar(current: number, max: number, length: number = 20): string {
    const filled = Math.round((current / max) * length);
    const empty = length - filled;
    return '█'.repeat(filled) + '░'.repeat(empty);
  }
}
