import { db } from './connection';
import { MemberStats, MessageActivity, ChannelStats, MemberEvent, DailySnapshot } from '../types/analytics';

export class AnalyticsRepository {
  // Guild Settings
  static upsertGuild(guildId: string, guildName: string): void {
    const stmt = db.prepare(`
      INSERT INTO guild_settings (guild_id, guild_name) 
      VALUES (?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET 
        guild_name = excluded.guild_name,
        updated_at = strftime('%s', 'now')
    `);
    stmt.run(guildId, guildName);
  }

  // Member Statistics
  static incrementMessageCount(guildId: string, userId: string, username: string, charCount: number): void {
    const today = Math.floor(Date.now() / 1000 / 86400) * 86400;
    
    const stmt = db.prepare(`
      INSERT INTO member_stats (guild_id, user_id, username, message_count, character_count, last_active)
      VALUES (?, ?, ?, 1, ?, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET
        message_count = message_count + 1,
        character_count = character_count + ?,
        last_active = ?,
        username = excluded.username
    `);
    stmt.run(guildId, userId, username, charCount, today, charCount, today);
  }

  static getTopUsers(guildId: string, limit: number = 10): MemberStats[] {
    const stmt = db.prepare(`
      SELECT user_id, username, message_count, character_count, voice_minutes, last_active
      FROM member_stats
      WHERE guild_id = ?
      ORDER BY message_count DESC
      LIMIT ?
    `);
    return stmt.all(guildId, limit) as MemberStats[];
  }

  static getMemberStats(guildId: string, userId: string): MemberStats | undefined {
    const stmt = db.prepare(`
      SELECT * FROM member_stats WHERE guild_id = ? AND user_id = ?
    `);
    return stmt.get(guildId, userId) as MemberStats | undefined;
  }

  // Message Activity
  static recordMessageActivity(guildId: string, channelId: string, userId: string, charCount: number): void {
    const today = Math.floor(Date.now() / 1000 / 86400) * 86400;
    
    const stmt = db.prepare(`
      INSERT INTO message_activity (guild_id, channel_id, user_id, message_count, character_count, date)
      VALUES (?, ?, ?, 1, ?, ?)
      ON CONFLICT DO UPDATE SET
        message_count = message_count + 1,
        character_count = character_count + ?
    `);
    stmt.run(guildId, channelId, userId, charCount, today, charCount);
  }

  static getActivityForDateRange(guildId: string, startDate: number, endDate: number): MessageActivity[] {
    const stmt = db.prepare(`
      SELECT date, SUM(message_count) as total_messages, COUNT(DISTINCT user_id) as active_users
      FROM message_activity
      WHERE guild_id = ? AND date >= ? AND date <= ?
      GROUP BY date
      ORDER BY date DESC
    `);
    return stmt.all(guildId, startDate, endDate) as MessageActivity[];
  }

  static getDailyStats(guildId: string, days: number = 7): any[] {
    const endDate = Math.floor(Date.now() / 1000);
    const startDate = endDate - (days * 86400);
    
    const stmt = db.prepare(`
      SELECT 
        date(date, 'unixepoch') as day,
        SUM(message_count) as messages,
        COUNT(DISTINCT user_id) as active_users
      FROM message_activity
      WHERE guild_id = ? AND date >= ?
      GROUP BY date
      ORDER BY date DESC
    `);
    return stmt.all(guildId, startDate) as any[];
  }

  // Channel Statistics
  static recordChannelMessage(guildId: string, channelId: string, channelName: string): void {
    const today = Math.floor(Date.now() / 1000 / 86400) * 86400;
    
    const stmt = db.prepare(`
      INSERT INTO channel_stats (guild_id, channel_id, channel_name, message_count, date)
      VALUES (?, ?, ?, 1, ?)
      ON CONFLICT(guild_id, channel_id, date) DO UPDATE SET
        message_count = message_count + 1,
        channel_name = excluded.channel_name
    `);
    stmt.run(guildId, channelId, channelName, today);
  }

  static getTopChannels(guildId: string, days: number = 7, limit: number = 10): ChannelStats[] {
    const startDate = Math.floor(Date.now() / 1000) - (days * 86400);
    
    const stmt = db.prepare(`
      SELECT channel_id, channel_name, SUM(message_count) as message_count
      FROM channel_stats
      WHERE guild_id = ? AND date >= ?
      GROUP BY channel_id
      ORDER BY message_count DESC
      LIMIT ?
    `);
    return stmt.all(guildId, startDate, limit) as ChannelStats[];
  }

  // Member Events (Join/Leave)
  static recordMemberEvent(guildId: string, userId: string, username: string, eventType: 'join' | 'leave'): void {
    const stmt = db.prepare(`
      INSERT INTO member_events (guild_id, user_id, username, event_type)
      VALUES (?, ?, ?, ?)
    `);
    stmt.run(guildId, userId, username, eventType);
  }

  static getMemberEvents(guildId: string, days: number = 7): { joins: number; leaves: number } {
    const startDate = Math.floor(Date.now() / 1000) - (days * 86400);
    
    const stmt = db.prepare(`
      SELECT event_type, COUNT(*) as count
      FROM member_events
      WHERE guild_id = ? AND event_date >= ?
      GROUP BY event_type
    `);
    const results = stmt.all(guildId, startDate) as { event_type: string; count: number }[];
    
    return {
      joins: results.find(r => r.event_type === 'join')?.count || 0,
      leaves: results.find(r => r.event_type === 'leave')?.count || 0
    };
  }

  static getRecentMemberEvents(guildId: string, limit: number = 10): MemberEvent[] {
    const stmt = db.prepare(`
      SELECT * FROM member_events
      WHERE guild_id = ?
      ORDER BY event_date DESC
      LIMIT ?
    `);
    return stmt.all(guildId, limit) as MemberEvent[];
  }

  // Daily Snapshots
  static createSnapshot(guildId: string, memberCount: number, messageCount: number, activeUsers: number): void {
    const today = Math.floor(Date.now() / 1000 / 86400) * 86400;
    
    const stmt = db.prepare(`
      INSERT INTO daily_snapshots (guild_id, snapshot_date, member_count, message_count, active_users)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guild_id, snapshot_date) DO UPDATE SET
        member_count = excluded.member_count,
        message_count = excluded.message_count,
        active_users = excluded.active_users
    `);
    stmt.run(guildId, today, memberCount, messageCount, activeUsers);
  }

  static getSnapshots(guildId: string, days: number = 30): DailySnapshot[] {
    const startDate = Math.floor(Date.now() / 1000) - (days * 86400);
    
    const stmt = db.prepare(`
      SELECT * FROM daily_snapshots
      WHERE guild_id = ? AND snapshot_date >= ?
      ORDER BY snapshot_date ASC
    `);
    return stmt.all(guildId, startDate) as DailySnapshot[];
  }

  // Voice Activity
  static startVoiceSession(guildId: string, channelId: string, userId: string): void {
    const stmt = db.prepare(`
      INSERT INTO voice_activity (guild_id, channel_id, user_id, join_time)
      VALUES (?, ?, ?, ?)
    `);
    stmt.run(guildId, channelId, userId, Math.floor(Date.now() / 1000));
  }

  static endVoiceSession(guildId: string, userId: string): void {
    const leaveTime = Math.floor(Date.now() / 1000);
    
    const stmt = db.prepare(`
      UPDATE voice_activity
      SET leave_time = ?,
          duration_minutes = ROUND((? - join_time) / 60.0)
      WHERE guild_id = ? AND user_id = ? AND leave_time IS NULL
      ORDER BY join_time DESC
      LIMIT 1
    `);
    stmt.run(leaveTime, leaveTime, guildId, userId);
  }

  // General Statistics
  static getTotalMessages(guildId: string): number {
    const stmt = db.prepare(`
      SELECT COALESCE(SUM(message_count), 0) as total FROM member_stats WHERE guild_id = ?
    `);
    const result = stmt.get(guildId) as { total: number };
    return result.total;
  }

  static getActiveUsersCount(guildId: string, days: number = 7): number {
    const startDate = Math.floor(Date.now() / 1000) - (days * 86400);
    
    const stmt = db.prepare(`
      SELECT COUNT(DISTINCT user_id) as count
      FROM message_activity
      WHERE guild_id = ? AND date >= ?
    `);
    const result = stmt.get(guildId, startDate) as { count: number };
    return result.count;
  }

  static getServerStats(guildId: string): any {
    const totalMessages = this.getTotalMessages(guildId);
    const activeUsers7d = this.getActiveUsersCount(guildId, 7);
    const activeUsers24h = this.getActiveUsersCount(guildId, 1);
    const memberEvents = this.getMemberEvents(guildId, 7);
    
    return {
      totalMessages,
      activeUsers24h,
      activeUsers7d,
      ...memberEvents
    };
  }
}