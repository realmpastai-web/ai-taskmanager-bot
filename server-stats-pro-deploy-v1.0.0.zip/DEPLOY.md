# ServerStats Pro - Deployment Guide

## Quick Deploy Options

### Option 1: Railway (Recommended - Easiest)

1. **Fork/Clone the repo to your GitHub**
   ```bash
   git clone https://github.com/realmpastai-web/discord-bots.git
   cd discord-bots
   ```

2. **Create Railway Account**
   - Go to https://railway.app
   - Sign up with GitHub

3. **Create New Project**
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Choose your forked repo

4. **Add Environment Variables**
   - In Railway dashboard, go to "Variables"
   - Add the following:
     ```
     DISCORD_TOKEN=your_bot_token_here
     CLIENT_ID=your_client_id_here
     NODE_ENV=production
     ```

5. **Deploy**
   - Railway will auto-deploy on push
   - Check logs in the "Deploy" tab

6. **Get Invite Link**
   - Once deployed, bot will be online
   - Use the invite URL from Discord Developer Portal

---

### Option 2: Docker (Self-Hosted)

1. **Install Docker**
   ```bash
   # Ubuntu/Debian
   curl -fsSL https://get.docker.com | sh
   ```

2. **Clone Repository**
   ```bash
   git clone https://github.com/realmpastai-web/discord-bots.git
   cd discord-bots
   ```

3. **Create Environment File**
   ```bash
   cp .env.example .env
   nano .env
   # Add your DISCORD_TOKEN and CLIENT_ID
   ```

4. **Build and Run**
   ```bash
   docker-compose up -d
   ```

5. **Check Logs**
   ```bash
   docker-compose logs -f
   ```

---

### Option 3: VPS with PM2

1. **Provision VPS** (Ubuntu 22.04 recommended)
   - DigitalOcean, Linode, or AWS
   - 1GB RAM minimum

2. **Install Node.js**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Clone and Setup**
   ```bash
   git clone https://github.com/realmpastai-web/discord-bots.git
   cd discord-bots
   npm install
   npm run build
   ```

4. **Create Environment**
   ```bash
   cp .env.example .env
   nano .env
   # Add DISCORD_TOKEN and CLIENT_ID
   ```

5. **Install PM2**
   ```bash
   npm install -g pm2
   ```

6. **Start Bot**
   ```bash
   pm2 start dist/index.js --name "serverstats-pro"
   pm2 save
   pm2 startup
   ```

7. **Monitor**
   ```bash
   pm2 logs serverstats-pro
   pm2 monit
   ```

---

## Discord Bot Setup

### 1. Create Discord Application

1. Go to https://discord.com/developers/applications
2. Click "New Application"
3. Name it "ServerStats Pro"
4. Go to "Bot" tab
5. Click "Add Bot"
6. Under "TOKEN", click "Reset Token" and copy it

### 2. Enable Intents

In the Bot tab, enable these Privileged Gateway Intents:
- ✅ SERVER MEMBERS INTENT
- ✅ MESSAGE CONTENT INTENT

### 3. Get Client ID

Go to "OAuth2" → "General" and copy "Client ID"

### 4. Generate Invite URL

Go to "OAuth2" → "URL Generator":
- Select Scope: `bot`
- Select Bot Permissions:
  - Send Messages
  - Embed Links
  - Attach Files
  - Read Message History
  - View Channels
  - Use Slash Commands

Copy the generated URL and invite the bot to your server.

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| DISCORD_TOKEN | Yes | Bot token from Discord Developer Portal |
| CLIENT_ID | Yes | Application ID from OAuth2 tab |
| NODE_ENV | No | Set to `production` for deployments |
| PORT | No | Health check port (default: 3000) |

---

## Health Check

The bot includes a health check endpoint at `/health`:

```bash
curl http://localhost:3000/health
```

Response:
```json
{
  "status": "ok",
  "uptime": 3600,
  "timestamp": "2024-03-05T12:00:00.000Z",
  "bot": {
    "username": "ServerStats Pro",
    "id": "123456789",
    "status": "connected"
  }
}
```

---

## Troubleshooting

### Bot won't start
- Check DISCORD_TOKEN is correct
- Verify intents are enabled in Discord Developer Portal
- Check logs: `docker-compose logs` or `pm2 logs`

### Commands not appearing
- Run deploy-commands script: `npm run deploy-commands`
- Wait up to 1 hour for global commands to propagate
- Check bot has "Use Slash Commands" permission

### Database errors
- Ensure `/app/data` directory is writable
- For Docker: check volume mount
- For VPS: ensure permissions with `chmod 755 data`

### Railway deployment fails
- Check environment variables are set
- Verify health check path is `/health`
- Check build logs in Railway dashboard

---

## Support

- **Email:** quantbitrealm@gmail.com
- **GitHub:** github.com/realmpastai-web
- **Response Time:** Within 24 hours

---

## Post-Deployment Checklist

- [ ] Bot shows as online in Discord
- [ ] `/help` command responds
- [ ] `/stats` shows server statistics
- [ ] Database file is being created (check `data/` directory)
- [ ] Health check endpoint returns 200 OK
- [ ] Logs show no errors

---

**Your ServerStats Pro bot is now live! 🎉**
