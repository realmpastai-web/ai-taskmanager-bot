# 📊 ServerStats Pro

A premium Discord server analytics bot that tracks member activity, message statistics, channel usage, and server growth. Built with TypeScript, SQLite, and discord.js v14.

![Bot Status](https://img.shields.io/badge/status-production-green)
![Node.js](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)
![TypeScript](https://img.shields.io/badge/typescript-5.3-blue)
![License](https://img.shields.io/badge/license-MIT-yellow)

## ✨ Features

- **📈 Real-time Analytics**
  - Message count tracking per user and channel
  - Member join/leave monitoring
  - Voice channel activity tracking
  - Character count statistics

- **📊 Comprehensive Commands**
  - `/stats` - View server overview with top channels and users
  - `/activity` - Daily activity charts with visual graphs
  - `/growth` - Server growth trends over 30 days
  - `/topusers` - Leaderboard of most active members
  - `/channelstats` - Channel usage statistics
  - `/export` - Export data as CSV or JSON (Admin only)

- **🎨 Visual Charts**
  - Beautiful growth charts using Chart.js
  - Activity bar graphs
  - Discord-dark themed visualizations

- **💾 Data Management**
  - SQLite database with WAL mode
  - Automated daily snapshots
  - CSV/JSON export functionality
  - Data persistence across restarts

## 🚀 Quick Start

### Prerequisites

- Node.js 18.0.0 or higher
- A Discord Bot Token ([Get one here](https://discord.com/developers/applications))

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/quantbitrealmSimon/discord-bots.git
cd discord-bots/server-stats-bot
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment**
```bash
cp .env.example .env
# Edit .env with your Discord token and client ID
```

4. **Deploy slash commands**
```bash
npm run deploy-commands
```

5. **Start the bot**
```bash
# Development mode
npm run dev

# Production mode
npm run build
npm start
```

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)

1. **Create your `.env` file**
```bash
cp .env.example .env
# Edit .env with your credentials
```

2. **Start the container**
```bash
docker-compose up -d
```

3. **Deploy commands** (first time only)
```bash
docker-compose exec server-stats-bot npm run deploy-commands
```

### Using Docker directly

```bash
# Build image
docker build -t server-stats-bot .

# Run container
docker run -d \
  --name server-stats-bot \
  --env-file .env \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/logs:/app/logs \
  server-stats-bot
```

## ⚙️ Configuration

Create a `.env` file with the following variables:

```env
# Required
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_application_client_id_here

# Optional
NODE_ENV=production
DATABASE_PATH=./data/analytics.db
LOG_LEVEL=info
```

### Discord Bot Setup

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application named "ServerStats Pro"
3. Go to "Bot" section and enable:
   - **Server Members Intent**
   - **Message Content Intent**
   - **Presence Intent** (optional)
4. Generate OAuth2 URL with these scopes:
   - `bot`
   - `applications.commands`
5. Add these permissions:
   - View Channels
   - Send Messages
   - Read Message History
   - Connect
   - Speak

## 📖 Command Reference

| Command | Description | Permissions |
|---------|-------------|-------------|
| `/stats` | Server overview with top channels/users | Everyone |
| `/activity` | Daily activity charts | Everyone |
| `/growth` | 30-day growth visualization | Everyone |
| `/topusers` | Most active users leaderboard | Everyone |
| `/channelstats` | Channel usage statistics | Everyone |
| `/export` | Export data (CSV/JSON) | Administrator |
| `/help` | Display help information | Everyone |

## 📸 Screenshots

### Server Statistics
![Stats Command](docs/screenshots/stats-command.png)

### Growth Chart
![Growth Command](docs/screenshots/growth-chart.png)

### Activity Report
![Activity Command](docs/screenshots/activity-chart.png)

### Top Users Leaderboard
![Top Users](docs/screenshots/top-users.png)

## 🏗️ Project Structure

```
server-stats-bot/
├── src/
│   ├── commands/           # Slash command handlers
│   │   ├── stats.ts
│   │   ├── activity.ts
│   │   ├── growth.ts
│   │   ├── topusers.ts
│   │   ├── channelstats.ts
│   │   ├── export.ts
│   │   └── help.ts
│   ├── events/             # Discord event handlers
│   │   ├── ready.ts
│   │   ├── messageCreate.ts
│   │   ├── guildMemberAdd.ts
│   │   ├── guildMemberRemove.ts
│   │   ├── voiceStateUpdate.ts
│   │   └── interactionCreate.ts
│   ├── services/           # Business logic
│   │   ├── analyticsService.ts
│   │   └── chartService.ts
│   ├── database/           # Database layer
│   │   ├── connection.ts
│   │   └── repository.ts
│   ├── types/              # TypeScript types
│   │   └── analytics.ts
│   ├── utils/              # Utilities
│   │   ├── logger.ts
│   │   └── formatters.ts
│   ├── index.ts            # Entry point
│   └── deploy-commands.ts  # Command deployment
├── data/                   # Database storage
├── logs/                   # Log files
├── temp/                   # Temporary exports
├── Dockerfile
├── docker-compose.yml
├── package.json
├── tsconfig.json
└── README.md
```

## 🔧 Database Schema

The bot uses SQLite with the following tables:

- `guild_settings` - Guild configuration
- `member_stats` - Per-user message and voice statistics
- `message_activity` - Daily message counts per user/channel
- `channel_stats` - Channel message statistics
- `member_events` - Join/leave tracking
- `daily_snapshots` - Growth tracking snapshots
- `voice_activity` - Voice channel usage tracking

## 📈 Pricing

This is a **premium tier bot** with a base price of **$150**.

Includes:
- Full source code
- Docker containerization
- Database setup
- 6 months of updates
- Basic setup support

## 🤝 Support

For support, feature requests, or custom modifications:
- Create an issue on GitHub
- Contact: quantbitrealm@gmail.com

## 📄 License

This project is licensed under the MIT License.

## 🙏 Credits

Built with:
- [discord.js](https://discord.js.org/) - Discord API library
- [Chart.js](https://www.chartjs.org/) - Charting library
- [better-sqlite3](https://github.com/WiseLibs/better-sqlite3) - SQLite driver
- [date-fns](https://date-fns.org/) - Date utilities

---

<p align="center">Made with ❤️ by QuantBitRealm</p>