# 📊 Telegram Analytics Bot

**Track your Telegram channel growth, engagement, and performance** - The analytics tool every channel owner needs.

[![Grammy](https://img.shields.io/badge/Grammy-Framework-blue)](https://grammy.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## ✨ Features

### 📈 Subscriber Analytics
- Real-time subscriber count tracking
- Daily/weekly/monthly growth charts
- Join/leave rate analysis
- Growth velocity alerts

### 📊 Post Performance
- Views, forwards, reactions tracking
- Best posting time recommendations
- Content engagement scoring
- Historical performance trends

### 🔔 Automated Reports
- Daily summary to channel admins
- Weekly growth reports
- Milestone celebrations (1K, 10K, 100K)
- Scheduled analytics exports

### 💬 Engagement Metrics
- Average views per post
- Forward/share rates
- Reaction analytics
- Peak activity hours

## 🚀 Commands

| Command | Description | Who Can Use |
|---------|-------------|-------------|
| `/start` | Initialize bot in channel | Admin |
| `/stats` | Current channel statistics | Admin |
| `/growth [days]` | Growth chart (7-90 days) | Admin |
| `/posts` | Post performance summary | Admin |
| `/report` | Generate full report | Admin |
| `/settings` | Configure bot settings | Admin |
| `/help` | Show help information | Everyone |

## 💰 Pricing

| Tier | Price | Features |
|------|-------|----------|
| **Free** | ₹0 | 30 days history, basic stats |
| **Premium** | ₹299/month | Unlimited history, CSV export, AI insights |
| **Lifetime** | ₹2499 | All features forever |

*Payments via Instamojo (India)*

## 🛠️ Setup

### 1. Create a Bot
1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Create new bot with `/newbot`
3. Copy your bot token

### 2. Add Bot to Channel
1. Add bot as admin to your channel
2. Give "Post Messages" and "Edit Messages" permissions
3. Send `/start` in the channel

### 3. Deploy

#### Docker (Recommended)
```bash
docker-compose up -d
```

#### Local
```bash
npm install
npm run build
npm start
```

## 📋 Environment Variables

```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
DATABASE_PATH=./data/analytics.db
ADMIN_CHAT_ID=your_telegram_id
```

## 📊 Data Collected

- Subscriber count (hourly snapshots)
- Post views, forwards, reactions
- User join/leave events
- Peak activity times

**Privacy**: All data stored locally. No external sharing.

## 🏗️ Architecture

```
src/
├── handlers/        # Command handlers
│   ├── commands.ts
│   └── callbacks.ts
├── services/        # Business logic
│   ├── analytics.ts
│   └── reports.ts
├── database/        # SQLite
├── config.ts
└── index.ts
```

## 📈 Roadmap

- [ ] Web dashboard for analytics
- [ ] Competitor channel tracking
- [ ] AI-powered content recommendations
- [ ] Multi-channel management
- [ ] Export to Google Sheets

## 🤝 Support

- Telegram: [@quantbitrealm](https://t.me/quantbitrealm)
- Email: support@quantbitrealm.com

---

Built with ❤️ by [QuantBitRealm](https://github.com/realmpastai-web)
