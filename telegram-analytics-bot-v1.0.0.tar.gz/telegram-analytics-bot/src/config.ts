import dotenv from 'dotenv';

dotenv.config();

export const config = {
  botToken: process.env.BOT_TOKEN || '',
  adminId: process.env.ADMIN_ID || '',
  databasePath: process.env.DATABASE_PATH || './data/analytics.db',
};

if (!config.botToken) {
  console.error('❌ BOT_TOKEN is required');
  process.exit(1);
}