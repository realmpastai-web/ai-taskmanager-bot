import { Bot, Context, session } from 'grammy';
import { config } from './config';
import { initDatabase } from './database';
import { setupCommands } from './handlers/commands';
import { setupChannelHandlers } from './handlers/channel';

async function main() {
  console.log('🚀 Starting Telegram Analytics Bot...');
  
  // Initialize database
  await initDatabase();
  
  // Create bot instance
  const bot = new Bot(config.botToken);
  
  // Setup session
  bot.use(session({ initial: () => ({}) }));
  
  // Setup handlers
  setupCommands(bot);
  setupChannelHandlers(bot);
  
  // Error handling
  bot.catch((err) => {
    console.error('❌ Bot error:', err);
  });
  
  // Start bot
  await bot.start();
  console.log('✅ Bot is running!');
  
  // Notify admin
  if (config.adminId) {
    try {
      await bot.api.sendMessage(
        config.adminId, 
        '📊 Analytics Bot is now online!\n\nAdd me to your channel as an admin to start tracking analytics.'
      );
    } catch (error) {
      console.log('Could not notify admin:', error);
    }
  }
}

main().catch(console.error);