import { Bot, Context } from 'grammy';
import { getDb } from '../database';

export function setupChannelHandlers(bot: Bot<Context>) {
  // Track new posts
  bot.on('channel_post', async (ctx) => {
    const channelId = ctx.chat?.id.toString();
    const messageId = ctx.channelPost?.message_id.toString();
    
    if (!channelId || !messageId) return;
    
    try {
      const db = getDb();
      
      // Store post reference for tracking
      await db.run(
        `INSERT OR IGNORE INTO posts (channel_id, message_id) VALUES (?, ?)`,
        [channelId, messageId]
      );
      
      console.log(`📨 Tracked new post in channel ${channelId}`);
    } catch (error) {
      console.error('Error tracking post:', error);
    }
  });
  
  // Track subscriber count changes (via chat member updates if available)
  bot.on('chat_member', async (ctx) => {
    const chatId = ctx.chat?.id.toString();
    const newCount = 'members_count' in ctx.chat ? ctx.chat.members_count : null;
    
    if (!chatId || !newCount) return;
    
    try {
      const db = getDb();
      await db.run(
        `INSERT INTO subscriber_snapshots (channel_id, subscriber_count) VALUES (?, ?)`,
        [chatId, newCount]
      );
      
      console.log(`👥 Updated subscriber count for ${chatId}: ${newCount}`);
    } catch (error) {
      console.error('Error tracking subscribers:', error);
    }
  });
}