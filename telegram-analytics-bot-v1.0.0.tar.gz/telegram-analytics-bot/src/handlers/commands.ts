import { Bot, Context } from 'grammy';
import { getDb } from '../database';

export function setupCommands(bot: Bot<Context>) {
  // Start command
  bot.command('start', async (ctx) => {
    const chatType = ctx.chat?.type;
    
    if (chatType === 'private') {
      await ctx.reply(
        '📊 <b>Telegram Analytics Bot</b>\n\n' +
        'Track your channel growth and engagement!\n\n' +
        '<b>To get started:</b>\n' +
        '1. Add me to your channel as an admin\n' +
        '2. Give me "Post Messages" permission\n' +
        '3. Use /stats in your channel\n\n' +
        'Use /help for more commands.',
        { parse_mode: 'HTML' }
      );
    } else {
      // In channel/group
      const channelId = ctx.chat?.id.toString();
      const channelName = 'title' in ctx.chat ? ctx.chat.title : 'Unknown';
      
      try {
        const db = getDb();
        await db.run(
          `INSERT OR REPLACE INTO channels (channel_id, channel_name) VALUES (?, ?)`,
          [channelId, channelName]
        );
        
        await ctx.reply(
          '✅ <b>Analytics Bot activated!</b>\n\n' +
          'I\'ll now track your channel statistics.\n' +
          'Use /stats to see your analytics.',
          { parse_mode: 'HTML' }
        );
      } catch (error) {
        console.error('Error registering channel:', error);
        await ctx.reply('❌ Error activating bot. Please try again.');
      }
    }
  });
  
  // Stats command
  bot.command('stats', async (ctx) => {
    const chatType = ctx.chat?.type;
    
    if (chatType === 'private') {
      await ctx.reply('📊 Use this command in a channel where I\'m an admin.');
      return;
    }
    
    const channelId = ctx.chat?.id.toString();
    
    try {
      const db = getDb();
      
      // Get latest subscriber count
      const snapshot = await db.get(
        `SELECT subscriber_count, recorded_at 
         FROM subscriber_snapshots 
         WHERE channel_id = ? 
         ORDER BY recorded_at DESC LIMIT 1`,
        [channelId]
      );
      
      // Get post stats
      const postStats = await db.get(
        `SELECT 
          COUNT(*) as total_posts,
          AVG(views) as avg_views,
          SUM(forwards) as total_forwards
         FROM posts 
         WHERE channel_id = ?`,
        [channelId]
      );
      
      // Get growth (last 7 days vs previous 7)
      const growth = await db.get(
        `SELECT 
          (SELECT subscriber_count FROM subscriber_snapshots 
           WHERE channel_id = ? AND recorded_at >= datetime('now', '-7 days')
           ORDER BY recorded_at ASC LIMIT 1) as start_count,
          (SELECT subscriber_count FROM subscriber_snapshots 
           WHERE channel_id = ?
           ORDER BY recorded_at DESC LIMIT 1) as current_count`,
        [channelId, channelId]
      );
      
      const currentCount = growth?.current_count || snapshot?.subscriber_count || 'N/A';
      const growthValue = growth?.start_count && growth?.current_count 
        ? growth.current_count - growth.start_count 
        : 0;
      const growthEmoji = growthValue >= 0 ? '📈' : '📉';
      
      await ctx.reply(
        `📊 <b>Channel Analytics</b>\n\n` +
        `👥 <b>Subscribers:</b> ${currentCount}\n` +
        `${growthEmoji} <b>7-day Growth:</b> ${growthValue > 0 ? '+' : ''}${growthValue}\n` +
        `📝 <b>Posts Tracked:</b> ${postStats?.total_posts || 0}\n` +
        `👁 <b>Avg Views:</b> ${Math.round(postStats?.avg_views || 0)}\n` +
        `🔄 <b>Total Forwards:</b> ${postStats?.total_forwards || 0}\n\n` +
        `<i>Use /growth for detailed charts</i>`,
        { parse_mode: 'HTML' }
      );
      
    } catch (error) {
      console.error('Error getting stats:', error);
      await ctx.reply('❌ Error fetching statistics. Please try again.');
    }
  });
  
  // Growth command
  bot.command('growth', async (ctx) => {
    const chatType = ctx.chat?.type;
    
    if (chatType === 'private') {
      await ctx.reply('📈 Use this command in a channel.');
      return;
    }
    
    const channelId = ctx.chat?.id.toString();
    const args = ctx.message?.text?.split(' ');
    const days = args && args[1] ? parseInt(args[1]) : 7;
    
    try {
      const db = getDb();
      
      const snapshots = await db.all(
        `SELECT subscriber_count, recorded_at 
         FROM subscriber_snapshots 
         WHERE channel_id = ? AND recorded_at >= datetime('now', '-${days} days')
         ORDER BY recorded_at ASC`,
        [channelId]
      );
      
      if (snapshots.length === 0) {
        await ctx.reply('📊 No data available yet. I\'ll collect data over time.');
        return;
      }
      
      const startCount = snapshots[0].subscriber_count;
      const endCount = snapshots[snapshots.length - 1].subscriber_count;
      const growth = endCount - startCount;
      const growthPercent = startCount > 0 ? ((growth / startCount) * 100).toFixed(1) : 0;
      
      await ctx.reply(
        `📈 <b>Growth Report (${days} days)</b>\n\n` +
        `📊 <b>Start:</b> ${startCount} subscribers\n` +
        `🎯 <b>Current:</b> ${endCount} subscribers\n` +
        `${growth >= 0 ? '📈' : '📉'} <b>Change:</b> ${growth > 0 ? '+' : ''}${growth} (${growthPercent}%)\n\n` +
        `<i>Data points: ${snapshots.length}</i>`,
        { parse_mode: 'HTML' }
      );
      
    } catch (error) {
      console.error('Error getting growth:', error);
      await ctx.reply('❌ Error fetching growth data.');
    }
  });
  
  // Help command
  bot.command('help', async (ctx) => {
    await ctx.reply(
      '📊 <b>Telegram Analytics Bot - Help</b>\n\n' +
      '<b>Channel Commands:</b>\n' +
      '/start - Activate bot in channel\n' +
      '/stats - Current statistics\n' +
      '/growth [days] - Growth chart (7-90 days)\n' +
      '/posts - Post performance\n\n' +
      '<b>Settings:</b>\n' +
      '/settings - Configure bot\n\n' +
      '<i>Add me to your channel as admin to start tracking!</i>',
      { parse_mode: 'HTML' }
    );
  });
}