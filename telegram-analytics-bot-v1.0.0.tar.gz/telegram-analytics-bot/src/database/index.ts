import { Database, open } from 'sqlite';
import sqlite3 from 'sqlite3';
import { config } from '../config';

let db: Database<sqlite3.Database, sqlite3.Statement>;

export async function initDatabase(): Promise<void> {
  db = await open({
    filename: config.databasePath,
    driver: sqlite3.Database,
  });
  
  console.log('📦 Database initialized');
  
  // Create tables
  await db.exec(`
    CREATE TABLE IF NOT EXISTS channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT UNIQUE NOT NULL,
      channel_name TEXT,
      added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      settings TEXT
    );
    
    CREATE TABLE IF NOT EXISTS subscriber_snapshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT NOT NULL,
      subscriber_count INTEGER,
      recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (channel_id) REFERENCES channels(channel_id)
    );
    
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT NOT NULL,
      message_id TEXT NOT NULL,
      views INTEGER DEFAULT 0,
      forwards INTEGER DEFAULT 0,
      reactions INTEGER DEFAULT 0,
      posted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (channel_id) REFERENCES channels(channel_id)
    );
    
    CREATE INDEX IF NOT EXISTS idx_snapshots_channel ON subscriber_snapshots(channel_id);
    CREATE INDEX IF NOT EXISTS idx_posts_channel ON posts(channel_id);
  `);
  
  console.log('✅ Database tables ready');
}

export function getDb(): Database<sqlite3.Database, sqlite3.Statement> {
  return db;
}