# Discord Moderator Bot

A professional Discord moderation bot built with **discord.js v14** featuring comprehensive moderation tools, user management, and server analytics.

![Discord.js Version](https://img.shields.io/badge/discord.js-v14.14.1-blue.svg)
![Node.js Version](https://img.shields.io/badge/node.js-%3E%3D18.0.0-green.svg)
![License](https://img.shields.io/badge/license-MIT-yellow.svg)

## ✨ Features

### 🛡️ Moderation Commands
- **Ban** - Ban users with optional message deletion
- **Kick** - Remove users from the server
- **Timeout** - Temporarily mute users (supports: 1m, 30m, 1h, 1d, 7d)
- **Warn** - Warning system with add/list/clear subcommands
- **Purge** - Bulk delete messages (1-100) with optional user filter

### 📊 Information Commands
- **Server Info** - Display detailed server statistics
- **User Info** - Show user details, roles, and status
- **Help** - Comprehensive command reference

### 🎉 Automatic Features
- **Welcome Messages** - Auto-welcome new members

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ installed
- Discord Bot Token ([Get one here](https://discord.com/developers/applications))

### Installation

1. **Clone the repository:**
```bash
git clone https://github.com/quantbitrealmSimon/discord-bots.git
cd discord-bots/moderator-bot
```

2. **Install dependencies:**
```bash
npm install
```

3. **Configure environment variables:**
```bash
cp .env.example .env
# Edit .env with your bot credentials
```

4. **Deploy slash commands:**
```bash
npm run deploy
```

5. **Start the bot:**
```bash
npm start
```

## 🔧 Configuration

Create a `.env` file with the following:

```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_application_id_here
```

### How to get credentials:

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application" → Name your bot
3. Go to "Bot" tab → Click "Reset Token" → Copy the token
4. Go to "General Information" → Copy "Application ID" (this is your CLIENT_ID)
5. Enable these Privileged Gateway Intents:
   - Server Members Intent
   - Message Content Intent

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)

```bash
docker-compose up -d
```

### Using Docker directly

```bash
docker build -t moderator-bot .
docker run -d --env-file .env --name moderator-bot moderator-bot
```

## 🔗 Invite Link

To invite the bot to your server, use this URL template:

```
https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=274877910080&scope=bot%20applications.commands
```

**Required Permissions:**
- Ban Members
- Kick Members
- Manage Messages
- Moderate Members
- Read Messages
- Send Messages
- Embed Links
- Read Message History

## 📋 Command Reference

| Command | Description | Permission |
|---------|-------------|------------|
| `/ban @user [reason] [days]` | Ban a user | Ban Members |
| `/kick @user [reason]` | Kick a user | Kick Members |
| `/timeout @user <duration> [reason]` | Timeout a user | Moderate Members |
| `/warn add @user <reason>` | Add warning | Moderate Members |
| `/warn list @user` | List warnings | Moderate Members |
| `/warn clear @user` | Clear warnings | Moderate Members |
| `/purge <amount> [@user]` | Delete messages | Manage Messages |
| `/serverinfo` | Server statistics | Everyone |
| `/userinfo [@user]` | User information | Everyone |
| `/help` | Show all commands | Everyone |

## 🏗️ Project Structure

```
moderator-bot/
├── src/
│   ├── commands/          # Slash command implementations
│   │   ├── ban.js
│   │   ├── kick.js
│   │   ├── timeout.js
│   │   ├── warn.js
│   │   ├── purge.js
│   │   ├── help.js
│   │   ├── serverinfo.js
│   │   └── userinfo.js
│   ├── events/            # Discord event handlers
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   └── guildMemberAdd.js
│   ├── utils/             # Utility functions
│   │   └── warnings.js
│   ├── index.js           # Bot entry point
│   └── deploy-commands.js # Command deployment script
├── .env.example           # Environment template
├── .gitignore            # Git ignore rules
├── docker-compose.yml    # Docker Compose config
├── Dockerfile            # Docker image definition
├── package.json          # Node.js dependencies
└── README.md             # This file
```

## 💰 Premium Features (Coming Soon)

- **Mod Logs** - Dedicated channel for moderation actions
- **Auto-Mod** - Automatic spam/word filter detection
- **Custom Commands** - Server-specific custom responses
- **Advanced Warnings** - Warning thresholds with auto-actions
- **Database Storage** - Persistent warning data
- **Dashboard** - Web interface for configuration

## 📝 License

MIT License - see [LICENSE](LICENSE) for details

## 🤝 Support

Need help? Contact us:
- GitHub Issues: [Report a bug](https://github.com/quantbitrealmSimon/discord-bots/issues)
- Email: support@quantbitrealm.com

---

Built with ❤️ by **QuantBitRealm**