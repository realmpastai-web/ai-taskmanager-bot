const { Events, EmbedBuilder } = require('discord.js');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    // Get the system channel or first text channel
    const channel = member.guild.systemChannel || 
                   member.guild.channels.cache.find(c => 
                     c.type === 0 && c.permissionsFor(member.guild.members.me).has('SendMessages')
                   );
    
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('👋 Welcome!')
      .setDescription(`Welcome to **${member.guild.name}**, ${member}!`)
      .addFields(
        { name: '📊 Member Count', value: `You are member #${member.guild.memberCount}` }
      )
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(console.error);
  }
};