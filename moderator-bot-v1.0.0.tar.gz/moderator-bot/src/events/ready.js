const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    console.log(`📊 Serving ${client.guilds.cache.size} server(s)`);
    console.log(`👥 Total members: ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)}`);
    
    // Set bot activity
    client.user.setActivity('/help for commands', { type: ActivityType.Playing });
    
    console.log('🤖 Bot is ready!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  }
};