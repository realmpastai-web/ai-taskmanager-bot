// Simple in-memory warning storage
// In production, use a database like MongoDB or PostgreSQL
const warnings = new Map();

function getKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

async function getWarnings(guildId, userId) {
  const key = getKey(guildId, userId);
  return warnings.get(key) || [];
}

async function addWarning(guildId, userId, moderatorId, reason) {
  const key = getKey(guildId, userId);
  const userWarnings = warnings.get(key) || [];
  
  const warning = {
    id: Date.now().toString(),
    userId,
    guildId,
    moderatorId,
    moderatorTag: moderatorId, // In real implementation, fetch actual tag
    reason,
    timestamp: Date.now()
  };
  
  userWarnings.push(warning);
  warnings.set(key, userWarnings);
  
  return warning;
}

async function clearWarnings(guildId, userId) {
  const key = getKey(guildId, userId);
  warnings.delete(key);
}

async function removeWarning(guildId, userId, warningId) {
  const key = getKey(guildId, userId);
  const userWarnings = warnings.get(key) || [];
  const filtered = userWarnings.filter(w => w.id !== warningId);
  warnings.set(key, filtered);
}

module.exports = {
  getWarnings,
  addWarning,
  clearWarnings,
  removeWarning
};