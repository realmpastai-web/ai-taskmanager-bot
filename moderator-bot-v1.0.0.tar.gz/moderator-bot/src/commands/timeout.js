const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout (mute) a user for a specified duration')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to timeout')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('duration')
        .setDescription('Duration (e.g., 1h, 30m, 1d, 7d)')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the timeout')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (target.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ You cannot timeout yourself!',
        ephemeral: true
      });
    }

    if (target.id === interaction.client.user.id) {
      return interaction.reply({
        content: '❌ You cannot timeout me!',
        ephemeral: true
      });
    }

    // Parse duration
    const durationRegex = /^(\d+)([smhdw])$/i;
    const match = durationStr.match(durationRegex);
    
    if (!match) {
      return interaction.reply({
        content: '❌ Invalid duration format. Use: `1h`, `30m`, `1d`, `7d`',
        ephemeral: true
      });
    }

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    const msPerUnit = {
      's': 1000,
      'm': 60 * 1000,
      'h': 60 * 60 * 1000,
      'd': 24 * 60 * 60 * 1000,
      'w': 7 * 24 * 60 * 60 * 1000
    };

    const durationMs = value * msPerUnit[unit];
    const maxTimeout = 28 * 24 * 60 * 60 * 1000; // 28 days max

    if (durationMs > maxTimeout) {
      return interaction.reply({
        content: '❌ Timeout cannot exceed 28 days!',
        ephemeral: true
      });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      
      if (!member) {
        return interaction.reply({
          content: '❌ That user is not in this server!',
          ephemeral: true
        });
      }

      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({
          content: '❌ You cannot timeout someone with a role equal or higher than yours!',
          ephemeral: true
        });
      }

      await member.timeout(durationMs, `${reason} | By ${interaction.user.tag}`);

      const unitLabels = { 's': 'seconds', 'm': 'minutes', 'h': 'hours', 'd': 'days', 'w': 'weeks' };

      const embed = new EmbedBuilder()
        .setColor(0xFFFF00)
        .setTitle('🔇 User Timed Out')
        .addFields(
          { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
          { name: 'Timed Out By', value: interaction.user.tag, inline: true },
          { name: 'Duration', value: `${value} ${unitLabels[unit]}`, inline: true },
          { name: 'Reason', value: reason }
        )
        .setTimestamp()
        .setThumbnail(target.displayAvatarURL({ dynamic: true }));

      await interaction.reply({ embeds: [embed] });

      // Try to DM the user
      try {
        await target.send({
          content: `🔇 You have been timed out in **${interaction.guild.name}** for ${value} ${unitLabels[unit]}\n**Reason:** ${reason}`
        });
      } catch (err) {
        // User has DMs disabled
      }

    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `❌ Failed to timeout user: ${error.message}`,
        ephemeral: true
      });
    }
  }
};