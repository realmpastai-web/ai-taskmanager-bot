const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Display information about a user')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to get info about')
        .setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    const embed = new EmbedBuilder()
      .setColor(member?.displayColor || 0x5865F2)
      .setTitle(`👤 ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🆔 User ID', value: target.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(target.createdTimestamp / 1000)}:R>`, inline: true }
      );

    if (member) {
      embed.addFields(
        { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '🏷️ Highest Role', value: member.roles.highest.toString() || 'None', inline: true },
        { name: '🎨 Nickname', value: member.nickname || 'None', inline: true },
        { name: '🎭 Roles', value: `${member.roles.cache.size - 1}` || '0', inline: true }
      );

      if (member.premiumSince) {
        embed.addFields({
          name: '✨ Boosting Since',
          value: `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>`,
          inline: true
        });
      }

      if (member.communicationDisabledUntil) {
        embed.addFields({
          name: '🔇 Timeout Until',
          value: `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>`,
          inline: true
        });
      }
    }

    embed.setFooter({ text: `Requested by ${interaction.user.tag}` })
         .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};