const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a user from the server')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to kick')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the kick')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (target.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ You cannot kick yourself!',
        ephemeral: true
      });
    }

    if (target.id === interaction.client.user.id) {
      return interaction.reply({
        content: '❌ You cannot kick me!',
        ephemeral: true
      });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      
      if (!member) {
        return interaction.reply({
          content: '❌ That user is not in this server!',
          ephemeral: true
        });
      }

      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({
          content: '❌ You cannot kick someone with a role equal or higher than yours!',
          ephemeral: true
        });
      }

      await member.kick(`${reason} | Kicked by ${interaction.user.tag}`);

      const embed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle('👢 User Kicked')
        .addFields(
          { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
          { name: 'Kicked By', value: interaction.user.tag, inline: true },
          { name: 'Reason', value: reason }
        )
        .setTimestamp()
        .setThumbnail(target.displayAvatarURL({ dynamic: true }));

      await interaction.reply({ embeds: [embed] });

      // Try to DM the kicked user
      try {
        await target.send({
          content: `👢 You have been kicked from **${interaction.guild.name}**\n**Reason:** ${reason}`
        });
      } catch (err) {
        // User has DMs disabled
      }

    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `❌ Failed to kick user: ${error.message}`,
        ephemeral: true
      });
    }
  }
};