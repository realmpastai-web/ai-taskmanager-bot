const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user from the server')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to ban')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the ban')
        .setRequired(false))
    .addIntegerOption(option =>
      option
        .setName('days')
        .setDescription('Number of days of messages to delete (0-7)')
        .setMinValue(0)
        .setMaxValue(7)
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('days') || 0;

    // Check if trying to ban self
    if (target.id === interaction.user.id) {
      return interaction.reply({
        content: '❌ You cannot ban yourself!',
        ephemeral: true
      });
    }

    // Check if trying to ban the bot
    if (target.id === interaction.client.user.id) {
      return interaction.reply({
        content: '❌ You cannot ban me!',
        ephemeral: true
      });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      
      // Check hierarchy if member is in guild
      if (member) {
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
          return interaction.reply({
            content: '❌ You cannot ban someone with a role equal or higher than yours!',
            ephemeral: true
          });
        }
      }

      await interaction.guild.members.ban(target, {
        deleteMessageDays: deleteDays,
        reason: `${reason} | Banned by ${interaction.user.tag}`
      });

      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🔨 User Banned')
        .addFields(
          { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
          { name: 'Banned By', value: interaction.user.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'Messages Deleted', value: `${deleteDays} day(s)` }
        )
        .setTimestamp()
        .setThumbnail(target.displayAvatarURL({ dynamic: true }));

      await interaction.reply({ embeds: [embed] });

      // Try to DM the banned user
      try {
        await target.send({
          content: `🔨 You have been banned from **${interaction.guild.name}**\n**Reason:** ${reason}`
        });
      } catch (err) {
        // User has DMs disabled
      }

    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `❌ Failed to ban user: ${error.message}`,
        ephemeral: true
      });
    }
  }
};