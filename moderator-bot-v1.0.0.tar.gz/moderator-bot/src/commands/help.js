const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available commands and bot information'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🛡️ Quant Moderator Bot')
      .setDescription('A professional moderation bot for Discord servers')
      .addFields(
        {
          name: '🔨 Ban',
          value: '`/ban @user [reason] [days]`\nBan a user from the server',
          inline: false
        },
        {
          name: '👢 Kick',
          value: '`/kick @user [reason]`\nKick a user from the server',
          inline: false
        },
        {
          name: '🔇 Timeout',
          value: '`/timeout @user <duration> [reason]`\nTimeout a user (e.g., 1h, 30m, 1d)',
          inline: false
        },
        {
          name: '⚠️ Warn',
          value: '`/warn add @user <reason>`\nAdd a warning\n`/warn list @user`\nView warnings\n`/warn clear @user`\nClear warnings',
          inline: false
        },
        {
          name: '🗑️ Purge',
          value: '`/purge <amount> [@user]`\nDelete messages (1-100)',
          inline: false
        },
        {
          name: 'ℹ️ Server Info',
          value: '`/serverinfo`\nShow server statistics',
          inline: false
        },
        {
          name: '👤 User Info',
          value: '`/userinfo [@user]`\nShow user information',
          inline: false
        }
      )
      .setFooter({ 
        text: 'Created by QuantBitRealm • v1.0.0',
        iconURL: interaction.client.user.displayAvatarURL()
      })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};