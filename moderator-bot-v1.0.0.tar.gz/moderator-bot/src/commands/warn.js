const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getWarnings, addWarning, clearWarnings } = require('../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user or manage warnings')
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add a warning to a user')
        .addUserOption(option =>
          option.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(option =>
          option.setName('reason').setDescription('Reason for warning').setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('List warnings for a user')
        .addUserOption(option =>
          option.setName('user').setDescription('User to check').setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('clear')
        .setDescription('Clear all warnings for a user')
        .addUserOption(option =>
          option.setName('user').setDescription('User to clear warnings for').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const target = interaction.options.getUser('user');
    const guildId = interaction.guild.id;

    if (target.id === interaction.user.id && subcommand === 'add') {
      return interaction.reply({
        content: '❌ You cannot warn yourself!',
        ephemeral: true
      });
    }

    try {
      if (subcommand === 'add') {
        const reason = interaction.options.getString('reason');
        const warning = await addWarning(guildId, target.id, interaction.user.id, reason);
        const totalWarnings = await getWarnings(guildId, target.id);

        const embed = new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle('⚠️ Warning Added')
          .addFields(
            { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
            { name: 'Warned By', value: interaction.user.tag, inline: true },
            { name: 'Reason', value: reason },
            { name: 'Total Warnings', value: `${totalWarnings.length}`, inline: true }
          )
          .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Try to DM the user
        try {
          await target.send({
            content: `⚠️ You have been warned in **${interaction.guild.name}**\n**Reason:** ${reason}\n**Total warnings:** ${totalWarnings.length}`
          });
        } catch (err) {
          // User has DMs disabled
        }

      } else if (subcommand === 'list') {
        const warnings = await getWarnings(guildId, target.id);

        if (warnings.length === 0) {
          return interaction.reply({
            content: `✅ ${target.tag} has no warnings.`,
            ephemeral: true
          });
        }

        const embed = new EmbedBuilder()
          .setColor(0x3498DB)
          .setTitle(`⚠️ Warnings for ${target.tag}`)
          .setDescription(`Total: ${warnings.length} warning(s)`);

        warnings.forEach((warn, index) => {
          embed.addFields({
            name: `Warning #${index + 1} - ${new Date(warn.timestamp).toLocaleDateString()}`,
            value: `**By:** ${warn.moderatorTag}\n**Reason:** ${warn.reason}`,
            inline: false
          });
        });

        await interaction.reply({ embeds: [embed], ephemeral: true });

      } else if (subcommand === 'clear') {
        await clearWarnings(guildId, target.id);

        const embed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Warnings Cleared')
          .setDescription(`All warnings for ${target.tag} have been cleared.`)
          .setTimestamp();

        await interaction.reply({ embeds: [embed] });
      }
    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `❌ An error occurred: ${error.message}`,
        ephemeral: true
      });
    }
  }
};