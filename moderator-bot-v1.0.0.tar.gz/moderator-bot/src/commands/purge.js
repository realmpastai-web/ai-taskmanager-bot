const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete multiple messages from a channel')
    .addIntegerOption(option =>
      option
        .setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true))
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('Only delete messages from this user')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const targetUser = interaction.options.getUser('user');

    try {
      const messages = await interaction.channel.messages.fetch({ limit: amount });
      
      let filteredMessages = messages;
      if (targetUser) {
        filteredMessages = messages.filter(msg => msg.author.id === targetUser.id);
      }

      // Filter out messages older than 14 days (Discord limitation)
      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      const deletableMessages = filteredMessages.filter(msg => msg.createdTimestamp > twoWeeksAgo);

      if (deletableMessages.size === 0) {
        return interaction.reply({
          content: '❌ No messages can be deleted (messages must be less than 14 days old)',
          ephemeral: true
        });
      }

      const deleted = await interaction.channel.bulkDelete(deletableMessages, true);

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🗑️ Messages Purged')
        .setDescription(`Successfully deleted **${deleted.size}** message(s)`)
        .addFields(
          targetUser 
            ? { name: 'Filter', value: `Only messages from ${targetUser.tag}` }
            : { name: 'Filter', value: 'All messages' }
        )
        .setFooter({ text: `Requested by ${interaction.user.tag}` })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });

    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `❌ Failed to purge messages: ${error.message}`,
        ephemeral: true
      });
    }
  }
};